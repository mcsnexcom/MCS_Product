#!/bin/bash

THISUSER=`whoami`
PRODUCT="$(tr -d '\0' < /proc/device-tree/product)"
ETHERNET=""
TERMINATOR="resources/terminator_1.91-4ubuntu1_all.deb"

TITLE_NM="`cat ./version.txt | grep "Test Tool Name" | awk -F : '{print $NF}'`"
TITLE_VER="`cat ./version.txt | grep "Test Tool Version" | awk -F : '{print $NF}'`"


RED='\033[0;31m'
YELLOW='\033[0;33m'
GREEN='\033[0;32m'
NC='\033[0m'

FUN_PASS=0
FUN_FAIL=1

CHK_ROOT(){
	if [ "x$THISUSER" != "xroot" ]; then
		echo -e "${RED}This script requires root privilege.${NC}"
		exit 1
	fi
}

CHK_ENV(){
	STATUS="`dpkg --get-selections | grep terminator`"
	if [ $? -eq $FUN_FAIL ]; then
		if [ -e `pwd`/${TERMINATOR} ]; then
			echo -e "${YELLOW}Install Terminator Package...${NC}"
			dpkg -i `pwd`/${TERMINATOR}
			echo -e "${YELLOW}Install Terminator success!${NC}"
			update-alternatives --set x-terminal-emulator /usr/bin/gnome-terminal.wrapper
		fi	
	fi	
	STATUS="`pip list | grep jetson-stats`"
	if [ $? -eq $FUN_FAIL ]; then
		echo -e "${YELLOW}Install JTOP Package...${NC}"
		ETH_STATUS="`timeout 1s ping -c 1 1.1.1.1 | grep ' 0% packet loss'`"
		if [ $? -eq $FUN_PASS ]; then
			pip install jetson-stats
			systemctl start jtop
			echo -e "${YELLOW}Install JTOP success!${NC}"
		else
			echo -e "${RED}Check ethernet status failed!!${NC}"
			exit
		fi
	fi

	if ! dpkg -s nvidia-cuda &> /dev/null; then
		echo -e "${YELLOW}Installing nvidia-cuda...${NC}"

		if ping -c 1 -W 1 1.1.1.1 > /dev/null 2>&1; then
			apt update && apt install -y nvidia-cuda

			if [ $? -eq 0 ]; then
				echo -e "${GREEN}CUDA toolkit installed successfully!${NC}"
			else
				echo -e "${RED}CUDA installation failed.${NC}"
				exit 1
			fi
		else
			echo -e "${RED}Cannot install CUDA: No internet connection!${NC}"
			exit 1
		fi
	fi
}

ERR_MSG(){
	zenity --warning --text="$1" --width 200 --height 50

}

OPTION(){
	INPUT=$(zenity --forms --title="${TITLE_NM}" --text="${TITLE_VER}\n\nSelect Option to Start Test\nProduct Name : ${PRODUCT}"	\
		--add-combo="Ethernet" --combo-values='Internal|External'	\
		--width 250 --height 50)
}

ARR_DATA(){
	PRODUCT="$(tr -d '\0' < /proc/device-tree/product)"
	ETHERNET="$INPUT"
}

CHK_OPTION(){
	if [ "$PRODUCT" = "ATC3530" ]; then
		echo -e "ATC35xx series."
		#PRODUCT="ATC3530"
	elif [ "$PRODUCT" = "ATC3540" ]; then
		echo -e "ATC3540 series."
		#PRODUCT="ATC3540"
	elif [ "$PRODUCT" = "ATC3541" ]; then
		echo -e "ATC3541 series."
		#PRODUCT="ATC3541"
	elif [ "$PRODUCT" = "ATC3542" ]; then
		echo -e "ATC3542 series."
		#PRODUCT="ATC3542"
	elif [ "$PRODUCT" = "ATC3521" ]; then
		echo -e "ATC3521 series."
		#PRODUCT="ATC3521"
	elif [ "$PRODUCT" = "ATC3522" ]; then
		echo -e "ATC3522 series."
		#PRODUCT="ATC3522"
	elif [ "$PRODUCT" = "ATC3520" ]; then
		echo -e "ATC3520 series."
		#PRODUCT="ATC3520"
	elif [ "$PRODUCT" = "ATC3560-NA" ]; then
		echo -e "ATC3560-NA series."
		#PRODUCT="ATC3560-NA"
	elif [ "$PRODUCT" = "ATC3561-NA" ]; then
		echo -e "ATC3561-NA series."
		#PRODUCT="ATC3561-NA"
	elif [ "$PRODUCT" = "ATC3562-NA" ]; then
		echo -e "ATC3562-NA series."
		#PRODUCT="ATC3562-NA"
	elif [ "$PRODUCT" = "ATC3563-NA" ]; then
		echo -e "ATC3563-NA series."
		#PRODUCT="ATC3563-NA"
	elif [ "$PRODUCT" = "ATC3560-NX" ]; then
		echo -e "ATC3560-NX series."
		#PRODUCT="ATC3560-NX"
	elif [ "$PRODUCT" = "ATC3561-NX" ]; then
		echo -e "ATC3561-NX series."
		#PRODUCT="ATC3561-NX"
	elif [ "$PRODUCT" = "ATC3562-NX" ]; then
		echo -e "ATC3562-NX series."
		#PRODUCT="ATC3562-NX"
	elif [ "$PRODUCT" = "ATC3563-NX" ]; then
		echo -e "ATC3563-NX series."
		#PRODUCT="ATC3563-NA"
	elif [ "$PRODUCT" = "ATC3750" ]; then
		echo -e "ATC3750 series."
		#PRODUCT="ATC3750"
	elif [ "$PRODUCT" = "ATC3750-8M" ]; then
		echo -e "ATC3750-8M series."
	elif [ "$PRODUCT" = "X80" ]; then
		echo -e "X80 series."
	else
		ERR_MSG "Please Select Product\n\nName to Start Test..."
		exit
	fi

	if [[ $ETHERNET =~ ^I ]]; then
		echo -e "Ethernet : Internal"
		ETHERNET="i"
	elif [[ $ETHERNET =~ ^E ]]; then
		echo -e "Ethernet : External"	
		ETHERNET="e"
	else
		ERR_MSG "Please Select Ethernet\n\noption to Start Test..."
		exit
	fi 
}



# Start to tes
# Parameters	$1: the mode of ethernet test
# Return		  : 0:Success|1:Fail
START_TEST() {
	#echo 460 > /sys/class/gpio/export  
	#echo out > /sys/class/gpio/gpio460/direction 
	#echo 0 >/sys/class/gpio/gpio460/value      

	chmod 0777 /dev/ttyTHS*

	systemctl stop NetworkManager
	# /etc/init.d/network-manager stop
	#bash connect_LTE.sh
	#ifconfig l4tbr0 down
	#ifconfig usb0 down
	#ifconfig lo down
	#ifconfig rndis0 down

	#sh set-Ethernet.sh $1
	bash set-Ethernet.sh $ETHERNET $PRODUCT

	echo -e "PRODUCT : $PRODUCT"
	echo -e "ETHERNET : $ETHERNET"
	CONFIG="${PRODUCT}_config.${ETHERNET}"
	echo -e "CONFIG FILE : $CONFIG"
	T_TITLE="${TITLE_NM}- ${TITLE_VER}--- ${PRODUCT}-${ETHERNET}"
	terminator --maximise --layout=Customized --working-directory=. --config=config/$CONFIG --title "${T_TITLE}" &
	
	return $FUN_PASS
}

CHK_ROOT
CHK_ENV
OPTION
ARR_DATA
CHK_OPTION
START_TEST

