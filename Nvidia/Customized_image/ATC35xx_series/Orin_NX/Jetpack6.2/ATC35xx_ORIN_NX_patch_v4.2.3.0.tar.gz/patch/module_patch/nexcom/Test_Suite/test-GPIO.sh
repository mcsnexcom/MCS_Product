#!/bin/bash

# For Ubuntu 
MCU_DEV="/dev/ttyTHS1"

KEEP_GO=1
WAIT_SECS=5

TMP_LOG_FILE="MDI.log"

testGPIO() {
	/bin/stty -F $MCU_DEV 115200 raw -echo -echoe -echok
	
#	# Active low in all of MDO
	echo -e "\xF1\x00\x03\x2F\x00\x`./bin/getCRC 00 03 2F 00`\xF2" > $MCU_DEV
#	# Set GPO pullup control enable
	echo -e "\xF1\x00\x03\x3B\x03\x`./bin/getCRC 00 03 3B 03`\xF2" > $MCU_DEV
	
	while [ $KEEP_GO = 1 ]
	do
		# Get MDI data from MCU
		cat $MCU_DEV > $TMP_LOG_FILE &
		sleep 1
		echo -e "\xF1\x00\x02\x30\xF4\xF2" > $MCU_DEV
		sync
		kill -9 `ps | grep "cat" | grep -v grep | awk '{print $1}'` > /dev/null 2>&1
		
		TMP_DATA="`hexdump -C $TMP_LOG_FILE | head -n 1`"
		COMMAND=`echo $TMP_DATA | awk '{print $3 $4 $5}'`
		TMP_DATA=`echo $TMP_DATA | awk '{print $6}'`
		if [ $COMMAND = "000230" ]; then	
			if [ "$TMP_DATA" = "00" ]; then
				echo -e "\033[32mGPIO(1~4) PASS\033[0m\n"
			else
				echo -e "\033[31mGPIO(1~4) FAIL\033[0m\n"
				echo -e "\033[31mMCU Data:$TMP_DATA\033[0m\n"
			fi
		fi			
		rm -f $TMP_LOG_FILE
		
		sleep $WAIT_SECS
	done
	
	# Active low in all of MDO
	echo -e "\xF1\x00\x03\x2F\x00\x`./bin/getCRC 00 03 2F 00`\xF2" > $MCU_DEV
}

catchSignal() {
	KEEP_GO=0
	echo "Stopping the shell script...";
}

trap "catchSignal" 2

testGPIO

echo "Finish stopping the shell script..."
