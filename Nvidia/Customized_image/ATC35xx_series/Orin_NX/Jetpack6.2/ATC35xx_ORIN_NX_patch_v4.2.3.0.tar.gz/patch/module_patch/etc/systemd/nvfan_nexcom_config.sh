#!/bin/bash

PRODUCT="`tr -d '\0' <	/proc/device-tree/product`"

case "${PRODUCT}" in
	#fan 5V
	ATC3541) cp /etc/nvfancontrol_5V.conf /etc/nvfancontrol.conf
	;;
	ATC3543) cp /etc/nvfancontrol_5V.conf /etc/nvfancontrol.conf
	;;
	ATC3561-NX) cp /etc/nvfancontrol_5V.conf /etc/nvfancontrol.conf
	;;
	ATC3563-NX) cp /etc/nvfancontrol_5V.conf /etc/nvfancontrol.conf
	;;
	#fan 12V
	ATC3540) cp /etc/nvfancontrol_12V.conf /etc/nvfancontrol.conf
	;;
	ATC3542) cp /etc/nvfancontrol_12V.conf /etc/nvfancontrol.conf
	;;
	ATC3560-NX) cp /etc/nvfancontrol_12V.conf /etc/nvfancontrol.conf
	;;
	ATC3562-NX) cp /etc/nvfancontrol_12V.conf /etc/nvfancontrol.conf
	;;
	#other
	X80) cp /etc/nvfancontrol_X80.conf /etc/nvfancontrol.conf
	;;
esac
