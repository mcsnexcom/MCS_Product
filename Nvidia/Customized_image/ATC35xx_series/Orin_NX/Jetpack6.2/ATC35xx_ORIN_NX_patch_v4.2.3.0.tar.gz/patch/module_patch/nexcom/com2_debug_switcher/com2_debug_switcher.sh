#!/bin/bash

EXTLINUX_CONF="/boot/extlinux/extlinux.conf"
PRODUCT=$(cat /proc/device-tree/product 2>/dev/null | tr -d '\0')

GREEN='\033[32m'
YELLOW='\033[33m'
GREEN_BG='\033[42;30m'
RED_BG='\033[41;30m'
RESET='\033[0m'

case "$PRODUCT" in
	"ATC3521"|"ATC3522"|"ATC3541"|"ATC3542"|"ATC3561-NA"|"ATC3561-NX"|"ATC3562-NA"|"ATC3562-NX"|"ATC3563-NA"|"ATC3563-NX")
		echo -e "Check product name ${GREEN}PASS${RESET}.\n"
		;;
	*)
		echo -e "${RED_BG}Error${RESET}: Unsupported product '$PRODUCT'. Supported products: ATC3521, ATC3522, ATC3541, ATC3542."
		exit 1
		;;
esac

if [ "$(id -u)" -ne 0 ]; then
	echo "${RED_BG}Error${RESET}: This script must be run as root."
	exit 1
fi

if [ ! -f "${EXTLINUX_CONF}" ]; then
	echo "${RED_BG}Error${RESET}: extlinux.conf not found!"
	exit 1
fi

echo "Select your configuration:"
echo -e "1) ${GREEN_BG}Enable COM2${RESET}, disable debug function"
echo -e "2) ${RED_BG}Disable COM2${RESET}, enable debug function"
read -rp "Enter you choice (1/2): " choice
echo

case $choice in
	1)
		sed -i 's/ console=ttyTCU0,115200//g' "${EXTLINUX_CONF}" 
		echo -e "${GREEN_BG}COM2 enabled${RESET}, debug function disabled.\n"
		;;
	2)
		sed -i 's/ console=ttyTCU0,115200//g' "${EXTLINUX_CONF}" 
		sed -i '/APPEND/s/[[:space:]]*$/ console=ttyTCU0,115200/' "${EXTLINUX_CONF}" 
		echo -e "${RED_BG}COM2 disabled${RESET}, debug function enabled.\n"
		;;
	*)
		echo -e "${RED_BG}Invalid choice. Please enter 1 or 2.${RESET}\n"
		exit 1
		;;
esac

echo -e "\n${YELLOW}Please remember to reboot your computer to apply the change.${RESET}\n"
