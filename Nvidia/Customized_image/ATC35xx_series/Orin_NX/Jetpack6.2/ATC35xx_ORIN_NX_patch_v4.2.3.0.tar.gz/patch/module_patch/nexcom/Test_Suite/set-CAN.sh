#!/bin/bash

### General variable by each shell script {
FUN_PASS=0
FUN_FAIL=1
###}

RED='\033[0;31m'
BLUE='\033[0;34m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

### Customized variable by each shell script {
CFG_NM="CAN modules"
MOD_1="can"
MOD_2="can_raw"
MOD_3="mttcan"
MOD_CNT=3
DEV_CNT=$1
### }

# To config the settings of socket CAN
# Return		  : 0:Success|1:Fail
cfgCAN() {
	echo -e "\033[36m[Start to set the CAN devices...]\033[0m"
	for DEV_IDX in $(seq 0 `expr $1 - 1`)
	do
		if [ "`ifconfig | grep can$DEV_IDX:`" = "" ]; then
			ip link set can$DEV_IDX type can bitrate 500000 dbitrate 2000000 berr-reporting on fd on
			TMP_RESULT=`expr $TMP_RESULT + $?`
			ip link set can$DEV_IDX up
			TMP_RESULT=`expr $TMP_RESULT + $?`
		fi
	done
	
	if [ $TMP_RESULT -eq $FUN_PASS ]; then
		echo -e "\033[36m[Setting the CAN devices successfully...]\033[0m"
		return $FUN_PASS
	else
		echo -e "\033[31mCan't set the CAN devices...\033[0m"
		return $FUN_FAIL
	fi
}

# Start to load CAN module
# Parameters	$1: the count of WIFI
# Return		  : 0:Success|1:Fail
loadModule() {
	TMP_RESULT=$FUN_PASS
	TMP_MOD="%sMOD_%d"
	echo -e "\033[36m[Start to load $CFG_NM...]\033[0m"
	for MOD_IDX in $(seq 1 $1)
	do
		TMP_VAR=`printf $TMP_MOD '$' $MOD_IDX`
		TMP_VAR=`eval "echo $TMP_VAR"`
		if [ "`lsmod | grep $TMP_VAR`" = "" ]; then
			modprobe $TMP_VAR 
			TMP_RESULT=`expr $TMP_RESULT + $?`
			echo -e "${GREEN}load $TMP_VAR success!!${NC}"
		else
			echo -e "${YELLOW}$TMP_VAR driver has been loaded.${NC}"
		fi
	done	
	
		echo -e "\033[36m[Loading $CFG_NM successfully...]\033[0m"
		return $FUN_PASS
}

# Start to install kernel module
# Return		  : 0:Success|1:Fail
execCMD() {
	loadModule $MOD_CNT
	if [ $? -eq $FUN_PASS ]; then
		cfgCAN $DEV_CNT
		if [ $? -eq $FUN_PASS ]; then
			return $FUN_PASS
		else
			return $FUN_FAIL
		fi
	else
		return $FUN_FAIL	
	fi
}

execCMD "$@"

