#!/bin/bash

#TMP="%d"
#CMD="\xF1\x$TMP\xF2"
#STR=` printf "$CMD" "2d"`
#echo -e "$STR"
TMP="\\\x%02X"
CRC_VAL=""
STR=""
FUN_PASS=0
FUN_FAIL=1
T_RESULT=$FUN_PASS
MCU_DEV="/dev/ttyTHS4"
DIR="/home/ai/LAB_ATC3xxx/bin/"
RED='\033[0;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

genCmd(){
	genCRC $@
	STR+="\\xF1"
	for CMD in $@	#CMD length 0xF1 ~ 0xF2
	do
		TMP_STR=`printf $TMP "0x$CMD"`
		#[DEBUG]
		#echo "CMD : $CMD , TMP_STR : $TMP_STR"
		STR+="$TMP_STR"
		TMP_STR=""
	done
	STR+="\\x$CRC_VAL\\xF2"
	CRC_VAL=""
	#[DEBUG]
	#echo $STR
}
genCRC(){
	#CRC_VAL=`/home/ai/tool/getCRC $*`
	CRC_VAL=`$DIR/getCRC $*`
	return $FUN_PASS
}

chkVal(){
i=1
#[DEBUG]
#echo -e "${YELLOW}Checking ALL argv...${NC}"
for CMD in $@
	do
                case "$CMD" in
                [a-fA-F0-9]|[a-fA-F0-9][a-fA-F0-9])
                        echo -e "${GREEN}check argv[$i] : $CMD value pass!!${NC}"
                ;;
                *)
                        echo -e "${RED}check argv[$i] : $CMD value failed.${NC}"
			T_RESULT=$(( $T_RESULT | $FUN_FAIL ))
                ;;
                esac
    		i=$((i+1))
    	done
return $T_RESULT
}
send_Cmd(){
	echo -e "$STR" > $MCU_DEV
	sleep 0.5
	return $FUN_PASS
}
sendMCU_Cmd(){
stty -F $MCU_DEV 115200 -echo -echok -echoe raw
#[DEBUG]
#chkVal "$@"
#$echo $T_RESULT
if [ $T_RESULT -eq $FUN_PASS ]; then
#if [ $? -eq $FUN_PASS ]; then
	#[DEBUG]
	# echo -e "${GREEN}check argv data ok !${NC}"
	genCmd "$@"
	if [ $? -eq $FUN_PASS ]; then
		send_Cmd
		if [ $? -eq $FUN_PASS ]; then
			echo -e "${GREEN}Send Command to MCU ok!!${NC}"
		fi
	fi
else
	echo -e "${RED}check argv is hex format.[Ex.] ./send_MCU_Cmd.sh 00 01 02${NC}"
fi
}

sendMCU_Cmd "$@"
#test a b c d
#test
#TMP=`grep -n "2" /home/nexcom/tool/text.txt | awk -F ':' '{print $1}'`
#echo $TMP
#TMP_I=`expr $TMP - 1` TMP_A=`expr $TMP + 1`
#sed "${TMP_I},${TMP_A}s/^/#/" /home/nexcom/tool/text.txt
