#!/bin/bash

# Remove files
sudo rm -f /usr/sbin/emucd_64
sudo rm -f /etc/init.d/run_emucd

# Copy files
sudo cp ../emucd_64 /usr/sbin
sudo cp ./run_emucd /etc/init.d

# Add Execute permission
sudo chmod +x /etc/init.d/run_emucd

# Update rc.d
sudo update-rc.d run_emucd defaults
