#!/bin/bash

/usr/bin/gpioset --mode=time --sec=5000000 -b 0 94=0

logger "GPIO 213 (PP,02) set to 0 during poweroff"
