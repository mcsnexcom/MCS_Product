#!/bin/bash

FUN_PASS=0
FUN_FAIL=1

PRODUCT=$(tr -d '\0' </proc/device-tree/product)

CHECK() {
	THISUSER=$(whoami)
	if [ "${THISUSER}" != "root" ]; then
		echo -e "\e[31mThis script requires root privilege\e[0m"
		exit 1
	fi

	if [ "$PRODUCT" != "X80" ]; then
		echo -e "\e[31mOnly support AIEdge-X80\e[0m"
		exit 1
	fi
	return $FUN_PASS
}

CLEAR_STAT() {
	SIG=$(ps -aux | grep gpioset | grep -v grep | awk -F " " '{printf " %s", $2}')
	if [ "$SIG" != "" ]; then
		kill -9 $SIG
	fi
	echo -e "\e[33mClear gpio status...\e[0m"
}

MODE_SELECT() {
	
	read -rp "RS485's mode: Receive or Transmit ? (r/t): " mode

    case "$mode" in
        [rR])
            echo "Receive data: Set High"
			CLEAR_STAT
            gpioset --mode=time --sec=31536000 -b 0 112=1
            ;;
        [tT])
            echo "Transmit data: Set Low"
			CLEAR_STAT
            gpioset --mode=time --sec=31536000 -b 0 112=0
            ;;
        *)
            echo "Invalid option! Please input [r] or [t]."
            exit 1
            ;;
    esac
}

CHECK
MODE_SELECT 
echo -e "\e[32mSet Mode OK!\e[0m"
