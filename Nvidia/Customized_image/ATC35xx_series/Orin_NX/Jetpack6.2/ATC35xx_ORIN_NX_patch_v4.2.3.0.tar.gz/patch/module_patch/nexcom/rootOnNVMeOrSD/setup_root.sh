#!/bin/bash
# if the user is not root, there is not point in going forward
THISUSER=`whoami`
if [ "${THISUSER}" != "root" ]; then
    echo "This script requires root privilege"
    exit 1
fi

PRODUCT=$(tr -d '\0' < /proc/device-tree/product)

if [[ $PRODUCT =~ ^ATC35[2|4]0$ ]]; then
	echo -e "\e[31m[Warning] This script doesn't support ATC3520 &3540\n\e[0m"
	echo -e "\e[31mbecause the root file system already on NVMe!! EXIT.\e[0m"
	exit
fi

read -p "Wanning: this script will ERASE all your SSD os sdcard data. Continue? (y/n)" read

if [ "${read}" != "y" ]; then
    exit 1
fi

read -p "1. SSD(nvme0n1) 2. SD card(mmcblk1)? (1/2)" read

if [ "${read}" == "1" ]; then
    DISK=/dev/nvme0n1
    DISK1=/dev/nvme0n1p1
    TYPE=ssd    
elif [ "${read}" == "2" ]; then
    DISK=/dev/mmcblk1
    DISK1=/dev/mmcblk1p1
    TYPE=sd
else
    exit 1
fi

umount $DISK
umount $DISK1
echo -e "o\nY\nn\n\n\n\n\nw\nY\n" | gdisk $DISK
echo -e "w\n" | fdisk $DISK
echo -e "y\n" | mkfs.ext4 $DISK1

# Mount the SSD as /mnt
mount $DISK1 /mnt
# Copy over the rootfs from the SD card to the SSD
if [ "$?" -eq "0" ]; then
rsync -axHAWX --numeric-ids --info=progress2 --exclude={"/dev/","/proc/","/sys/","/tmp/","/run/","/mnt/","/media/*","/lost+found"} / /mnt
# We want to keep the SSD mounted for further operations
# So we do not unmount the SSD
else
echo "mount $DISK1 failed."
exit 1
fi

	
# Setup the service to set the rootfs to point to the SSD
cp data/set${TYPE}root.service /etc/systemd/system
cp data/set${TYPE}root.sh /sbin
chmod 777 /sbin/set${TYPE}root.sh
systemctl daemon-reload
systemctl enable set${TYPE}root.service

# Copy these over to the SSD
cp /etc/systemd/system/set${TYPE}root.service /mnt/etc/systemd/system/set${TYPE}root.service
cp /sbin/set${TYPE}root.sh /mnt/sbin/set${TYPE}root.sh

# Create setsdroot.conf which tells the service script to set the rootfs to the SD card
# If you want to boot from EMMC again, remove the file /etc/setsdroot.conf from the EMMC.
# touch creates an empty file
touch /etc/set${TYPE}root.conf
echo 'Service to set the rootfs to the SSD/SDcard installed.'
echo 'Make sure that you have copied the rootfs to SSD / SDcard.'
echo 'Reboot for changes to take effect.'

