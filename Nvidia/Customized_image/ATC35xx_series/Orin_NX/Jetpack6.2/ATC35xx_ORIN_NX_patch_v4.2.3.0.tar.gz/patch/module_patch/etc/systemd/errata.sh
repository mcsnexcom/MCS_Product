#!/bin/bash

I2CBUS="1"
I2CADDR="0x5f"

chk_dev() {
	DEV=${I2CADDR#0x}
	#echo "DEV=$DEV"
	for retry in {1..3};do
		echo "Check Device: $retry "
		if i2cdetect -r -y "${I2CBUS}" | grep -q "${DEV}";then
			echo "Device found at 0x${DEV} on I2C bus ${I2CBUS}"
			break
		else
			echo "No device found at 0x${DEV} on I2C bus ${I2CBUS}"
			if [[ $retry == 3 ]];then
				exit 1
			fi
			sleep 3
		fi
	done
}

read_mmd() {
	port=$1
	mmd=$2
	register=$3
	i2ctransfer -y 1 w4@${I2CADDR} 0x"${port}"1 0x1A 0x00 "${mmd}"
	i2ctransfer -y 1 w4@${I2CADDR} 0x"${port}"1 0x1C 0x00 "${register}"
	i2ctransfer -y 1 w4@${I2CADDR} 0x"${port}"1 0x1A 0x80 "${mmd}"
	i2ctransfer -y 1 w2@${I2CADDR} 0x"${port}"1 0x1C r2
}

chk_mmd() {
	port=$1
	mmd=$2
	register=$3
	data1=$4
	data2=$5
	i2ctransfer -y 1 w4@${I2CADDR} 0x"${port}"1 0x1A 0x00 "${mmd}"
	i2ctransfer -y 1 w4@${I2CADDR} 0x"${port}"1 0x1C 0x00 "${register}"
	i2ctransfer -y 1 w4@${I2CADDR} 0x"${port}"1 0x1A 0x40 "${mmd}"
	output=$(i2ctransfer -y 1 w2@${I2CADDR} 0x"${port}"1 0x1C r2)
	read -r recv1 recv2 <<<"$output"

	if [[ "${data1,,}" == "${recv1,,}" ]] && [[ "${data2,,}" == "${recv2,,}" ]]; then
		#echo "Check Data PASS ."
		return 0
	else
		echo "Data write failed"
		echo "mmd,register=0x$2,0x$3"
		echo "data=$4 $5"
		echo "Received bytes: $output"
		return 1
	fi

}

write_mmd() {
	port=$1
	mmd=$2
	register=$3
	data1=$4
	data2=$5
	for attempt in {1..3}; do
		if [[ $attempt != 1 ]]; then
			echo
			echo "Retry time: $((attempt - 1))"
		fi
		i2ctransfer -y 1 w4@${I2CADDR} 0x"${port}"1 0x1A 0x00 "${mmd}"
		i2ctransfer -y 1 w4@${I2CADDR} 0x"${port}"1 0x1C 0x00 "${register}"
		i2ctransfer -y 1 w4@${I2CADDR} 0x"${port}"1 0x1A 0x40 "${mmd}"
		i2ctransfer -y 1 w4@${I2CADDR} 0x"${port}"1 0x1C "${data1}" "${data2}"

		if [[ $mmd == 0x1C ]] && [[ $register == 0x08 ]]; then
			break
		fi

		if chk_mmd "${port}" "${mmd}" "${register}" "${data1}" "${data2}"; then
			break
		fi

		sleep 3
		if [ "$attempt" = 3 ]; then
			echo "End of write trying, failed"
			echo
		fi
	done
}

wrtie_errata_1() {
	port=$1
	write_mmd "${port}" 0x01 0x6F 0xDD 0x0B
	write_mmd "${port}" 0x01 0x8F 0x60 0x32
	write_mmd "${port}" 0x01 0x9D 0x24 0x8C
	write_mmd "${port}" 0x01 0x75 0x00 0x60
	write_mmd "${port}" 0x01 0xD3 0x77 0x77
	write_mmd "${port}" 0x1C 0x06 0x30 0x08
	write_mmd "${port}" 0x1C 0x08 0x20 0x01
}

read_errata_1() {
	port=$1
	read_mmd "${port}" 0x01 0x6F
	read_mmd "${port}" 0x01 0x8F
	read_mmd "${port}" 0x01 0x9D
	read_mmd "${port}" 0x01 0x75
	read_mmd "${port}" 0x01 0xD3
	read_mmd "${port}" 0x1C 0x06
	read_mmd "${port}" 0x1C 0x08
}

wrtie_errata_2() {
	port=$1
	write_mmd "${port}" 0x1C 0x04 0x00 0xD0
}

wrtie_errata_3() {
	port=$1
	write_mmd "${port}" 0x07 0x3C 0x00 0x00
}

wrtie_errata_4() {
	port=$1
	write_mmd "${port}" 0x1C 0x13 0x6E 0xFF
	write_mmd "${port}" 0x1C 0x14 0x6E 0xFF
	write_mmd "${port}" 0x1C 0x15 0x6E 0xFF
	write_mmd "${port}" 0x1C 0x16 0xE6 0xFF
	write_mmd "${port}" 0x1C 0x17 0x00 0xFF
	write_mmd "${port}" 0x1C 0x18 0x43 0xFF
	write_mmd "${port}" 0x1C 0x19 0xC3 0xFF
	write_mmd "${port}" 0x1C 0x1A 0x6F 0xFF
	write_mmd "${port}" 0x1C 0x1B 0x07 0xFF
	write_mmd "${port}" 0x1C 0x1C 0x0F 0xFF
	write_mmd "${port}" 0x1C 0x1D 0xE7 0xFF
	write_mmd "${port}" 0x1C 0x1E 0xEF 0xFF
	write_mmd "${port}" 0x1C 0x20 0xEE 0xEE
}
#read_errata_1 3

# port=$1
# wrtie_errata_1 ${port}
# wrtie_errata_2 ${port}
# wrtie_errata_3 ${port}
# wrtie_errata_4 ${port}
chk_dev
sleep 5
for port in $(seq 1 5); do
	echo "==== Executing errata for port $port ===="
	wrtie_errata_1 "${port}"
	wrtie_errata_2 "${port}"
	wrtie_errata_3 "${port}"
	wrtie_errata_4 "${port}"
done
