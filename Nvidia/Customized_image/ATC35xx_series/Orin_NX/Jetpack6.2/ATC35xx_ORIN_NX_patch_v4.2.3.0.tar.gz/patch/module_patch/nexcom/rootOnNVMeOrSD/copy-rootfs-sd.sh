#!/bin/bash
# Mount the SDcard as /mnt
sudo mount /dev/mmcblk1p1 /mnt
# Copy over the rootfs from the EMMC to the SDcard
sudo rsync -axHAWX --numeric-ids --info=progress2 --exclude={"/dev/","/proc/","/sys/","/tmp/","/run/","/mnt/","/media/*","/lost+found"} / /mnt
# We want to keep the SDcard mounted for further operations
# So we do not unmount the SDcard
