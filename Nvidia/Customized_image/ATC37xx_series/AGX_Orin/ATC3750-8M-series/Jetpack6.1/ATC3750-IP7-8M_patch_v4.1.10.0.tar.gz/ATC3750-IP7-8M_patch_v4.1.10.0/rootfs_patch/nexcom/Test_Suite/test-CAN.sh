#!/bin/bash

### General variable by each shell script {
KEEP_GO=1
WAIT_SECS=5
###}

### Customized variable by each shell script {
COMP_STR="$2"
### }

### Counter {
COUNT_PASS=0
COUNT_FAIL=0
###}

# To test data transportation between two can devices
# Return		  : 0:Success|1:Fail
testCAN() {
	while [ $KEEP_GO = 1 ]
	do	
		# Prepare receiving data from can
		for CAN_IDX in $(seq 0 `expr $1 - 1`)
		do
			candump can$CAN_IDX > tmp$CAN_IDX.log &
		done
		
	  	if [ "$1" -eq "1" ]; then
			
			if [ "${COMP_STR}" != "" ]; then
				# Enter specified message
				echo "Please send data starting with:${COMP_STR}"
			else
				# Enter casual message
				echo "Please send data(within 3 seconds)"
			fi
		fi	
	
		sleep 3
		
		# Sending data into another can ( if CAN Bus > 1, then start loopback test)
		if [ "$1" -eq "2" ]; then
			cansend can$CAN_IDX "123#${COMP_STR}"
		fi
		
		# Judging the received data from can
		for CAN_IDX in $(seq 0 `expr $1 - 1`)
		do
			# Enter specified message
			if [ "${COMP_STR}" != "" ]; then
				TMP_DATA="`cat tmp$CAN_IDX.log | head -n 1 | awk '{print $4$5}'`"
				echo "Received data(first 4 hex):$TMP_DATA"
				rm -f tmp$CAN_IDX.log	
				if [ "$COMP_STR" = "$TMP_DATA" ]; then
					COUNT_PASS=$(( COUNT_PASS + 1))
					echo -e "\033[32mSocket CAN$CAN_IDX TEST PASS\033[0m [$COUNT_PASS]\n"
				else
					COUNT_FAIL=$(( COUNT_FAIL + 1))
					echo -e "\033[31mSocket CAN$CAN_IDX TEST FAIL\033[0m [$COUNT_FAIL]\n"
				fi
			
			# Enter casual message
			else
				TMP_DATA="`cat tmp$CAN_IDX.log | head -n 1| tr -s ' '| cut -d' ' -f5-`"
				echo "Received data:$TMP_DATA"
				rm -f tmp$CAN_IDX.log
				if [ "$TMP_DATA" != "" ]; then
					COUNT_PASS=$(( COUNT_PASS + 1))
					echo -e "\033[32mSocket CAN$CAN_IDX TEST PASS\033[0m [$COUNT_PASS]\n"
				else
					COUNT_FAIL=$(( COUNT_FAIL + 1))
					echo -e "\033[31mSocket CAN$CAN_IDX TEST FAIL\033[0m [$COUNT_FAIL]\n"
				fi
			fi
		done
		
		# Kill backgroung program
		killall candump
	
		sleep $WAIT_SECS	
	done
	
	return 0
}

catchSignal() {
	KEEP_GO=0
	echo "Stopping the shell script...";
}

trap "catchSignal" 2

bash set-CAN.sh $1
testCAN $1

echo "Finish stopping the shell script..."

