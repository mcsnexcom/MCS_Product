#!/bin/bash
# if the user is not root, there is not point in going forward
THISUSER=`whoami`
_VERSION=v4.1.10.0

if [ "x$THISUSER" != "xroot" ]; then
    echo "This script requires root privilege"
    exit 1
fi

function internal_massflash_package(){
########## Internal Storage ########

#ATC3750-8M 32G
VERSION="${_VERSION}_8M_AGX_ORIN_32G"
sed -i "1s/.*/${VERSION}/" rootfs/etc/image_version
#ATC3750-8M_mfi_v4.1.8.0_AGX_ORIN_32G.tar.gz

#offline mode
sudo PACKAGE_NAME=ATC3750-IP7-8M_mfi_$VERSION BOARDID=3701 FAB=500 BOARDSKU=0004 BOARDREV=M.0 ./tools/kernel_flash/l4t_initrd_flash.sh --no-flash --massflash 5 atc3750-8M-orin mmcblk0p1
#online mode
#sudo PACKAGE_NAME=ATC3750-8M_mfi_$VERSION  ./tools/kernel_flash/l4t_initrd_flash.sh --no-flash --massflash 5 atc3750-8M-orin mmcblk0p1

#ATC3750-8M 64G
VERSION="${_VERSION}_8M_AGX_ORIN_64G"
sed -i "1s/.*/${VERSION}/" rootfs/etc/image_version
#ATC3750-8M_mfi_v4.1.8.0_AGX_ORIN_32G.tar.gz

#offline mode
sudo PACKAGE_NAME=ATC3750-IP7-8M_mfi_$VERSION BOARDID=3701 FAB=500 BOARDSKU=0005 BOARDREV=M.0 ./tools/kernel_flash/l4t_initrd_flash.sh --no-flash --massflash 5 atc3750-8M-orin mmcblk0p1
#online mode
#sudo PACKAGE_NAME=ATC3750-8M_mfi_$VERSION  ./tools/kernel_flash/l4t_initrd_flash.sh --no-flash --massflash 5 atc3750-8M-orin mmcblk0p1
}

function external_massflash_package(){
########## External Storage ########

##AGX Orin 32G External Storage
VERSION="${_VERSION}_NVMe_8M_AGX_ORIN_32G"
sed -i "1s/.*/${VERSION}/" rootfs/etc/image_version

sudo PACKAGE_NAME=ATC3750-IP7-8M_mfi_${VERSION} \
    BOARDID=3701 FAB=500 BOARDSKU=0004 BOARDREV=M.0 \
    ./tools/kernel_flash/l4t_initrd_flash.sh --no-flash --external-device nvme0n1p1 \
    -p "-c bootloader/generic/cfg/flash_t234_qspi.xml --no-systemimg" \
    -c tools/kernel_flash/flash_l4t_t234_nvme.xml \
    --massflash 5 --showlogs --network usb0 \
    atc3750-8M-orin external

## AGX Orin 64G External Storage
VERSION="${_VERSION}_NVMe_8M_AGX_ORIN_64G"
sed -i "1s/.*/${VERSION}/" rootfs/etc/image_version

sudo PACKAGE_NAME=ATC3750-IP7-8M_mfi_${VERSION} \
    BOARDID=3701 FAB=500 BOARDSKU=0005 BOARDREV=M.0 \
    ./tools/kernel_flash/l4t_initrd_flash.sh --no-flash --external-device nvme0n1p1 \
    -p "-c bootloader/generic/cfg/flash_t234_qspi.xml --no-systemimg" \
    -c tools/kernel_flash/flash_l4t_t234_nvme.xml \
    --massflash 5 --showlogs --network usb0 \
    atc3750-8M-orin external
}

## for AGX Orin eMMC package ##
internal_massflash_package

## for AGX Orin NVMe package ##
#external_massflash_package
