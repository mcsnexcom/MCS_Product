[Install]
A. General install
    1. sudo modprobe emuc2socketcan
    2. sudo ./emucd_64 -s9 ttyACM0
    3. sudo ip link set emuccan0 up qlen 1000
    4. sudo ip link set emuccan1 up qlen 1000
B. Auto install
    1. sudo ./start.sh
C. Set auto enable when boot up
    1. sudo ./bootexec/add_2_boot.sh


[Remove]
1. sudo pkill -2 emucd_64
2. sudo rmmod emuc2socketcan.ko

