#!/bin/bash

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'
NVME_COUNT_PASS=0
NVME_COUNT_FAIL=0

trap cleanup EXIT

function cleanup {
        echo -e "${RED} NVMe SSD STRESS STOP!${NC}"
}


test(){
	while true
	do
	sudo hdparm -Tt /dev/nvme0n1p1
	if [ $? != 0 ]; then
		NVME_COUNT_FAIL=$(( NVME_COUNT_FAIL + 1 ))
		echo -e "${RED} NVMe SSD TEST FAILED ! ${NC} [$NVME_COUNT_FAIL]"
	else
		NVME_COUNT_PASS=$(( NVME_COUNT_PASS + 1 ))
		echo -e "${GREEN} NVMe SSD STRESS TESTING... ${NC} [$NVME_COUNT_PASS]"
	fi
	sleep 5
	done
}

test
