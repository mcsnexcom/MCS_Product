#!/bin/bash

KEEP_GO=1
WAIT_SECS=3
COUNT_PASS=0
COUNT_FAIL=0
PRODUCT="`tr -d '\0' < /proc/device-tree/product`"

pingIP() {
	while [ $KEEP_GO = 1 ]
	do
		RESULT="`ping -c 1 $1`"
		echo "$RESULT"
		TMP_DATA=`echo "$RESULT" | grep ' 0% packet loss'`
		if [ "$TMP_DATA" != "" ]; then
			COUNT_PASS=$(( $COUNT_PASS + 1 ))
			echo -e "\033[32mPing test PASS\033[0m [$COUNT_PASS]\n"
		else
			COUNT_FAIL=$(( $COUNT_FAIL + 1 ))
			echo -e "\033[31mPing test FAIL\033[0m [$COUNT_FAIL]\n"
		fi
		sleep $WAIT_SECS
	done
}

#for PoE
ping_LAN_SWITCH_IP() {
	LAN_CNT=""
	if [[ $PRODUCT =~ ^ATC35 ]]; then
		LAN_CNT=4
	elif [[ "$PRODUCT" = "ATC3750" ]]; then
		LAN_CNT=6
	elif [[ "$PRODUCT" = "ATC3750-8M" ]]; then
		LAN_CNT=1
	fi
	IP_ADR=$(expr `expr 2 + $LAN_CNT` - 1)	
        while [ $KEEP_GO = 1 ]
        do
		
		for COUNT in $(seq 2 $IP_ADR)
		do	
			NUMBER=`echo $1 | rev | cut -d'.' -f 3 | rev`
			IP="172."$NUMBER".0."$COUNT
                	RESULT="`ping -c 1 $IP`"
                	echo "$RESULT"
                	TMP_DATA=`echo "$RESULT" | grep ' 0% packet loss'`
                	if [ "$TMP_DATA" != "" ]; then
				COUNT_PASS=$(( $COUNT_PASS + 1 ))
                	        echo -e "\033[32mPing test PASS\033[0m [$COUNT_PASS]\n"
                	else
				COUNT_FAIL=$(( $COUNT_FAIL + 1 ))
                	        echo -e "\033[31mPing test FAIL\033[0m [$COUNT_FAIL]\n"
                	fi
                	sleep $WAIT_SECS
		done
        done
}


catchSignal() {
	KEEP_GO=0
	echo "Stopping the shell script...";
}

execCMD() {
	if [ $# -ge 1 ]; then
  		case $1 in
			"1")
				pingIP 10.60.0.1
			;;
			"2")
				pingIP 10.60.1.1
			;;
			"POE")
				ping_LAN_SWITCH_IP $2 $3
			;;

			"ETH")
				pingIP $2 $3
			;;
		esac
	fi
	
	return 0
}

trap "catchSignal" 2

execCMD $*

echo "Finish stopping the shell script..."
