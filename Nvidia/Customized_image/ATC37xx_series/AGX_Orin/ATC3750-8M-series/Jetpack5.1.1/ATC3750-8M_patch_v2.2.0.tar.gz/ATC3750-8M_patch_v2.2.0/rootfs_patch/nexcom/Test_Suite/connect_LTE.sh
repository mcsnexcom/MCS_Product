#!/bin/bash

sudo service network-manager stop
wait
mmcli --modem 0 --enable
wait
mmcli --modem 0 --simple-connect="apn=internet"
wait
BEARER=$(mmcli --modem 0 | grep Bearer | rev | cut -d '/' -f1 | rev)
wait
mmcli --bearer $BEARER
wait
ADDRESS=$(mmcli --bearer $BEARER | grep "address" | rev | cut -d' ' -f1 | rev)
wait
GATEWAY=$(mmcli --bearer $BEARER | grep "gateway" | rev | cut -d' ' -f1 | rev)
wait
DNS="nameserver 168.95.1.1"
DNS2="nameserver 168.95.192.1"
echo $ADDRESS
echo $GATEWAY

ifconfig wwan0 $ADDRESS
wait
route add default gw $GATEWAY wwan0
wait
echo $DNS >> /etc/resolv.conf
echo $DNS2 >> /etc/resolv.conf

