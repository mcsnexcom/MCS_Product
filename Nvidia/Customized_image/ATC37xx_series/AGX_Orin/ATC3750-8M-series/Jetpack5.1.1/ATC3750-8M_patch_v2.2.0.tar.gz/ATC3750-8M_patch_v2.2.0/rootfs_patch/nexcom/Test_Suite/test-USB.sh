#!/bin/bash

# For Ubuntu 
DEV_PATH="/proc/partitions"

KEEP_GO=1
WAIT_SECS=3

STORAGE_PATH=""
COUNT=1
COUNT_OTG_PASS=0
COUNT_OTG_FAIL=0
COUNT_SD_PASS=0
COUNT_SD_FAIL=0
COUNT_OTG_DETECT=0
COUNT_SD_DETECT=0

testUSB() {

	while [ $KEEP_GO = 1 ]
	do
		#get otg device
        	OTG_DEVICE=`ls -l /sys/dev/block/ | grep 1-1 | tail -n 1 | rev |  cut -d '/' -f 1 | rev`

		# for SATA storage(dtype=1)
		COUNT=1
		cat $DEV_PATH | grep $OTG_DEVICE | awk '{print $4}' > TMP_FILE
		#COUNT=`cat $DEV_PATH | grep sda1 | wc -l`
		if [ `cat TMP_FILE | wc -l` -gt 0 ]; then
			while read devNM;
			do
				STORAGE_PATH="`mount | grep "/dev/$devNM " | head -n 1 | awk '{print $3}'`"
				echo "TEST" > $STORAGE_PATH/USBTEST
				if [ "`cat $STORAGE_PATH/USBTEST`" = "TEST" ]; then
					COUNT_OTG_PASS=$(( $COUNT_OTG_PASS + 1 ))
					echo -e "\033[32m   USB OTG[$COUNT]-$devNM : PASS\033[0m [$COUNT_OTG_PASS]\n"
				else
					COUNT_OTG_FAIL=$(( $COUNT_OTG_FAIL + 1 ))
					echo -e "\033[31m   USB OTG[$COUNT]-$devNM : FAIL\033[0m [$COUNT_OTG_FAIL]\n"
				fi
				COUNT=`expr $COUNT + 1`
			done < TMP_FILE
			rm -f TMP_FILE
		#	awk -vdtype=1 -f awk_parse TMP_FILE
		else
			COUNT_OTG_DETECT=$(( $COUNT_OTG_DETECT + 1 ))
			echo -e "\033[31mNo OTG storage detected\033[0m [$COUNT_OTG_DETECT]\n"
		fi
		
		# for USB stick(dtype=2)
		COUNT=1
		cat $DEV_PATH | grep sd[a-z]1 | awk '{print $4}' > TMP_FILE
		##COUNT=`cat $DEV_PATH | grep sd[b-z]1 | wc -l`
		if [ `cat TMP_FILE | wc -l` -gt 0 ]; then
			while read devNM;
			do
				STORAGE_PATH="`mount | grep "/dev/$devNM " | head -n 1 | awk '{print $3}'`"
				echo "TEST" > $STORAGE_PATH/USBTEST
				if [ "`cat $STORAGE_PATH/USBTEST`" = "TEST" ]; then
					echo -e "\033[32m    USB[$COUNT]-$devNM : PASS\033[0m\n"
				else
					echo -e "\033[31m    USB[$COUNT]-$devNM : FAIL\033[0m\n"
				fi
				COUNT=`expr $COUNT + 1`
			done < TMP_FILE
			rm -f TMP_FILE
		#	awk -vdtype=2 -f awk_parse TMP_FILE
		else
			echo -e "\033[31mNo USB stick detected\033[0m\n"
		fi
		
		# for SD card(dtype=3)
		if [ `cat $DEV_PATH | grep mmcblk1p1 | wc -l` -gt 0 ]; then
			COUNT=1
			cat $DEV_PATH | grep mmcblk1p1 | awk '{print $4}' > TMP_FILE
			#COUNT=`cat $DEV_PATH | grep mmcblk1p1 | wc -l`
			if [ `cat TMP_FILE | wc -l` -gt 0 ]; then
				while read devNM;
				do
					STORAGE_PATH="`mount | grep "/dev/$devNM " | head -n 1 | awk '{print $3}'`"
					echo "TEST" > $STORAGE_PATH/USBTEST
					if [ "`cat $STORAGE_PATH/USBTEST`" = "TEST" ]; then
						COUNT_SD_PASS=$(( $COUNT_SD_PASS +1 ))
						echo -e "\033[32mSD card[$COUNT]-$devNM : PASS\033[0m [$COUNT_SD_PASS]\n"
					else
						COUNT_SD_FAIL=$(( $COUNT_SD_FAIL +1 ))
						echo -e "\033[31mSD card[$COUNT]-$devNM : FAIL\033[0m [$COUNT_SD_FAIL]\n"
					fi
					COUNT=`expr $COUNT + 1`
				done < TMP_FILE
				rm -f TMP_FILE
			#	awk -vdtype=3 -f awk_parse TMP_FILE
			else
				COUNT_SD_DETECT=$(( $COUNT_SD_DETECT +1 ))
				echo -e "\033[31mNo SD card detected\033[0m [$COUNT_SD_DETECT]\n"
			fi
		fi
		sleep $WAIT_SECS
	done
}

catchSignal() {
	KEEP_GO=0
	echo "Stopping the shell script...";
}

trap "catchSignal" 2

testUSB

echo "Finish stopping the shell script..."
