#!/bin/bash

# For Ubuntu

KEEP_GO=1
WAIT_SECS=3
COUNT_PASS=0
COUNT_FAIL=0

catHTML() {
	while [ $KEEP_GO = 1 ]
		do
		wget http://www.google.com
		cat index.html | awk -F " " '{print $1}'
		rm -f index.html
		sleep 3
	done
}

pingIP() {
        while [ $KEEP_GO = 1 ]
        do
                RESULT="`ping -c 1 $1`"
                echo "$RESULT"
                TMP_DATA=`echo "$RESULT" | grep ' 0% packet loss'`
                if [ "$TMP_DATA" != "" ]; then
			COUNT_PASS=$(( $COUNT_PASS + 1 ))
                        echo -e "\033[32mWifi Ping test PASS\033[0m [$COUNT_PASS]\n"
                else
			COUNT_FAIL=$(( $COUNT_FAIL + 1 ))
                        echo -e "\033[31mWifi Ping test FAIL\033[0m [$COUNT_FAIL]\n"
                fi
                sleep $WAIT_SECS
        done
}

#pingIP() {
#	while [ $KEEP_GO = 1 ]
#	do
#		ping -c 1 $1
#		sleep $WAIT_SECS
#	done
#}

actWIFI() {

	ifconfig wlan0 192.168.0.10 netmask 255.255.255.0
	iwconfig wlan0 essid "atc3530_a"

	case $1 in
		0)
			pingIP $2
		;;
		1)
			pingIP $2
		;;
	esac
}

catchSignal() {
	KEEP_GO=0
	echo "Stopping the shell script...";
}

trap "catchSignal" 2

actWIFI $1 $2 # arg1:which device 0:wlan0|1:wlan1 ; arg2:IP

echo "Finish stopping the shell script..."
