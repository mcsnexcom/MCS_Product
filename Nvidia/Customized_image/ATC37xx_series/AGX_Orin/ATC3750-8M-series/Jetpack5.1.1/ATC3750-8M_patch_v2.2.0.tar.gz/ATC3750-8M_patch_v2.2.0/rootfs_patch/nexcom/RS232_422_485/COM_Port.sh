#!/bin/bash

FUN_PASS=0
FUN_FAIL=1

PRODUCT=$(tr -d '\0' < /proc/device-tree/product) 

CHECK(){
	THISUSER=`whoami`
	if [ "${THISUSER}" != "root" ]; then
        	echo -e "\e[31mThis script requires root privilege\e[0m"
        	exit 1
	fi

	if [ "$PRODUCT" != "ATC3750-8M" ]; then
		echo -e "\e[31mCom1 convert only support ATC3750-8M\e[0m"
		exit 1
	fi
	return $FUN_PASS
}


# gpioset 0 70	PK.06 	Mode_0 		default high
# gpioset 0 71	PK.07	Mode_1		default low
# gpioset 1 28	PEE.05	Terminal	default low
# gpioset 0 112	PR.04	Dir		default low

# +==========+===========+========+===================+===============+===============+
# |          | LOOP BACK | RS-232 | RS422/RS485(full) | RS485-w(half) | RS485-r(half) |
# +==========+===========+========+===================+===============+===============+
# | Mode 0   |     0	 |    0   |	    0	      |	      1	      |	      1	      |
# +==========+===========+========+===================+===============+===============+
# | Mode 1   |     0	 |    1   |	    0	      |	      0	      |	      0	      |
# +==========+===========+========+===================+===============+===============+
# | Terminal |     0	 |    1   |	    0	      |	      0	      |	      0	      |
# +==========+===========+========+===================+===============+===============+
# | Dir      |     0	 |    1   |	    0	      |	      0	      |	      1	      |
# +==========+===========+========+===================+===============+===============+

MODE_SELECT(){
		case $1 in
                "RS232")
			gpioset 0 70=0
			gpioset 0 71=1
			gpioset 1 28=1
			gpioset 0 112=1
		;;
		RS422|RS485)
			gpioset 0 70=0
			gpioset 0 71=0
			gpioset 1 28=0
			gpioset 0 112=0
		;;
		"RS485-w") # RS485 half-duplex (write
			gpioset 0 70=1
			gpioset 0 71=0
			gpioset 1 28=0
			gpioset 0 112=0
		;;

		"RS485-r") # RS485 half-duplex (read
			gpioset 0 70=1
			gpioset 0 71=0
			gpioset 1 28=0
			gpioset 0 112=1
		;;
		*)
                        echo -e "\e[31mHelp : sudo -s\e[0m"
                        echo -e "\e[31mHelp : bash ./COM_Port.sh RS232|RS422|RS485|RS485-w|RS485-r\e[0m"
                        exit
                ;;
		esac	
}


CHECK
MODE_SELECT $1
echo -e "\e[32mSet $1 Mode OK!\e[0m"
