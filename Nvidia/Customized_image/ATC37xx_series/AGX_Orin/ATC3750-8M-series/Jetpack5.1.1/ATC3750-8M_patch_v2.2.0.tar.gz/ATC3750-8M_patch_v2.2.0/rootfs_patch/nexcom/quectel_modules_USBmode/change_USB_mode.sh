#!/bin/bash

# if the user is not root, there is not point in going forward
THISUSER=`whoami`
if [ "${THISUSER}" != "root" ]; then
        echo "This script requires root privilege"
        exit 1
fi

WAIT_TIME=200
SERIAL_DEV="/dev/ttyUSB3"

#COMMANDS
USBMODE_0="AT+QCFG="\""usbnet"\"",0\r"
USBMODE_2="AT+QCFG="\""usbnet"\"",2\r"
RESET="AT+CFUN=1,1\r"

echo -e $USBMODE_2 | busybox microcom -t $WAIT_TIME $SERIAL_DEV
echo -e $RESET | busybox microcom -t $WAIT_TIME $SERIAL_DEV
