#!/bin/bash

# Setting the ip tables and route tables
# Ethernet 1
ETH0_IP=10.50.0.1
ETH0_FAKE_IP=10.60.0.1
# Ethernet 2
ETH1_IP=10.50.1.1
ETH1_FAKE_IP=10.60.1.1

# Wlan 1
WLAN0_IP=1.1.1.1
WLAN0_FAKE_IP=1.1.1.1

ETH="$1"
ETH_IP=""
POE_IP=""
ETH_IP="172.20.0.1"
POE_IP="172.30.0.1"
if [ "$2" = "ATC3530" ]; then
	ETH_BUS="2490000"
	POE_BUS="14160000.pcie"
elif [ "$2" = "ATC3540" ]; then
	ETH_BUS="140a0000"
	POE_BUS="14100000.pcie"
elif [ "$2" = "ATC3750" ]; then
	ETH_BUS="6810000.ethernet"
	POE_BUS="2310000.ethernet"
elif [ "$2" = "ATC3750-8M" ]; then
	ETH_BUS="2310000.ethernet"
	POE_BUS="141a0000.pcie"
fi


echo "start"
ETH_NM="`ls -l /sys/class/net/ | grep "$ETH_BUS" | grep eth | awk -F / '{print $NF}'`"
POE_NM="`ls -l /sys/class/net/ | grep "$POE_BUS" | grep eth | awk -F / '{print $NF}'`"
ETH_MAC="`sudo ifconfig $ETH_NM | grep ether | awk '{print $2}'`"
POE_MAC="`sudo ifconfig $POE_NM | grep ether | awk '{print $2}'`"

ETH0_MAC=""
ETH1_MAC=""

showUsage() {
	echo "USAGE: sh set-Ethernet.sh {options}"
	echo "{options}"
	echo "  h help, list usage"
	echo "  e setting ip for external ping test"
	echo "  i setting ip for internal ping test"
}

setIP() {
	if [ "$ETH" = "e" ]; then			# external internet
		echo "ETH NM : $ETH_NM"
		echo "POE NM : $POE_NM"
		echo "ETH IP : $ETH_IP"
		echo "POE IP : $POE_IP"
		sudo ifconfig ${ETH_NM} "${ETH_IP}/24"
		sudo ifconfig ${POE_NM} "${POE_IP}/24"
	elif [ "$ETH" = "i" ]; then			# internal internet
		ETH0_NM="eth0"
		ETH1_NM="eth1"
		sudo ifconfig $ETH0_NM $ETH0_IP/24
	        sudo ifconfig $ETH1_NM $ETH1_IP/24
		ETH0_MAC="`sudo ifconfig $ETH0_NM | grep ether | awk '{print $2}'`"
		ETH1_MAC="`sudo ifconfig $ETH1_NM | grep ether | awk '{print $2}'`"
	fi

}

setRouteAndIPTables() {
        # nat source IP 10.50.0.1 -> 10.60.0.1 when going to 10.60.1.1
        sudo iptables -t nat -A POSTROUTING -s $ETH0_IP -d $ETH1_FAKE_IP -j SNAT --to-source $ETH0_FAKE_IP

        # nat inbound 10.60.0.1 -> 10.50.0.1
        sudo iptables -t nat -A PREROUTING -d $ETH0_FAKE_IP -j DNAT --to-destination $ETH0_IP

        # nat source IP 10.50.1.1 -> 10.60.1.1 when going to 10.60.0.1
        sudo iptables -t nat -A POSTROUTING -s $ETH1_IP -d $ETH0_FAKE_IP -j SNAT --to-source $ETH1_FAKE_IP

        # nat inbound 10.60.1.1 -> 10.50.1.1
        sudo iptables -t nat -A PREROUTING -d $ETH1_FAKE_IP -j DNAT --to-destination $ETH1_IP

        sudo ip route add $ETH1_FAKE_IP dev $ETH0_NM
        sudo arp -i $ETH0_NM -s $ETH1_FAKE_IP $ETH1_MAC # eth1's mac address

        sudo ip route add $ETH0_FAKE_IP dev $ETH1_NM
        sudo arp -i $ETH1_NM -s $ETH0_FAKE_IP $ETH0_MAC # eth0's mac address
}


execCMD() {
	if [ $# -ge 1 ]; then
  		case $1 in
			"h")
				showUsage
			;;
			"e")
				ETH_IP=172.20.0.1
				POE_IP=172.30.0.1
				setIP
			;;
			"i") 
				setIP
				setRouteAndIPTables
			;;
		esac
  	else
		showUsage
	fi
	
	return 0
}

execCMD $*
