#!/bin/bash

i=0;PD=0;ETH=1;	#PD=PRODUCT,ETH=ETHERNET
THISUSER=`whoami`
PRODUCT=""
CHK_PRODUCT="`tr -d '\0' < /proc/device-tree/product`"
ETHERNET=""
TERMINATOR="resources/terminator_1.91-4ubuntu1_all.deb"

TITLE_NM="`cat ./version.txt | grep "Test Tool Name" | awk -F : '{print $NF}'`"
TITLE_VER="`cat ./version.txt | grep "Test Tool Version" | awk -F : '{print $NF}'`"


RED='\033[0;31m'
YELLOW='\033[0;33m'
GREEN='\033[0;32m'
NC='\033[0m'

FUN_PASS=0
FUN_FAIL=1

CHK_ROOT(){
	if [ "x$THISUSER" != "xroot" ]; then
		echo -e "${RED}This script requires root privilege.${NC}"
		exit 1
	fi
}

CHK_ENV(){
	STATUS="`dpkg --get-selections | grep terminator`"
	if [ $? -eq $FUN_FAIL ]; then
		if [ -e `pwd`/${TERMINATOR} ]; then
			echo -e "${YELLOW}Install Terminator Package...${NC}"
			dpkg -i `pwd`/${TERMINATOR}
			echo -e "${YELLOW}Install Terminator success!${NC}"

		fi	
	fi	
	STATUS="`pip list | grep jetson-stats`"
	if [ $? -eq $FUN_FAIL ]; then
		echo -e "${YELLOW}Install JTOP Package...${NC}"
		ETH_STATUS="`timeout 1s ping -c 1 8.8.8.8 | grep ' 0% packet loss'`"
		if [ $? -eq $FUN_PASS ]; then
			pip install jetson-stats
			systemctl start jtop
			echo -e "${YELLOW}Install JTOP success!${NC}"
		else
			echo -e "${RED}Check ethernet status failed!!${NC}"
			exit
		fi
	fi
}

ERR_MSG(){
	zenity --warning --text="$1" --width 200 --height 50

}

OPTION(){
	INPUT=$(zenity --forms --title="${TITLE_NM}" --text="${TITLE_VER}\n\nSelect Option to Start Test"	\
		--add-combo="Product" --combo-values='ATC3530|ATC3540|ATC3750|ATC3750-8M'	\
		--add-combo="Ethernet" --combo-values='Internal|External'	\
		--width 250 --height 50)
}

ARR_DATA(){
	for DATA in ${INPUT//|/ }
	do
		TMP_DATA[i]=$DATA
		i=$((i+1))
	done
	PRODUCT=${TMP_DATA[$PD]}
	ETHERNET=${TMP_DATA[$ETH]}
}

CHK_OPTION(){
	if [ "$PRODUCT" != "$CHK_PRODUCT" ]; then
		ERR_MSG "This Product Name is : $CHK_PRODUCT\n\nYou Selected Product is : $PRODUCT\n\nCheck Failed!!\n\nRe-launch again."
		exit
	fi
	if [ "$PRODUCT" = "ATC3530" ]; then
		echo -e "ATC35xx series."
		#PRODUCT="ATC3530"
	elif [ "$PRODUCT" = "ATC3540" ]; then
		echo -e "ATC3540 series."
		#PRODUCT="ATC3540"
	elif [ "$PRODUCT" = "ATC3750" ]; then
		echo -e "ATC3750 series."
		#PRODUCT="ATC3750"
	elif [ "$PRODUCT" = "ATC3750-8M" ]; then
		echo -e "ATC3750-8M series."
	else
		ERR_MSG "Please Select Product\n\nName to Start Test..."
		exit
	fi

	if [[ $ETHERNET =~ ^I ]]; then
		echo -e "Ethernet : Internal"
		ETHERNET="i"
	elif [[ $ETHERNET =~ ^E ]]; then
		echo -e "Ethernet : External"	
		ETHERNET="e"
	else
		ERR_MSG "Please Select Ethernet\n\noption to Start Test..."
		exit
	fi 
}



# Start to tes
# Parameters	$1: the mode of ethernet test
# Return		  : 0:Success|1:Fail
START_TEST() {
	#echo 460 > /sys/class/gpio/export  
	#echo out > /sys/class/gpio/gpio460/direction 
	#echo 0 >/sys/class/gpio/gpio460/value      

	chmod 0777 /dev/ttyTHS*

	/etc/init.d/network-manager stop
	#bash connect_LTE.sh
	#ifconfig l4tbr0 down
	#ifconfig usb0 down
	#ifconfig lo down
	#ifconfig rndis0 down

	#sh set-Ethernet.sh $1
	bash set-Ethernet.sh $ETHERNET $PRODUCT

	echo -e "PRODUCT : $PRODUCT"
	echo -e "ETHERNET : $ETHERNET"
	CONFIG="${PRODUCT}_config.${ETHERNET}"
	echo -e "CONFIG FILE : $CONFIG"
	T_TITLE="${TITLE_NM}- ${TITLE_VER}--- ${PRODUCT}-${ETHERNET}"
	terminator --maximise --layout=Customized --working-directory=. --config=config/$CONFIG --title "${T_TITLE}" &
	
	return $FUN_PASS
}

CHK_ROOT
CHK_ENV
OPTION
ARR_DATA
CHK_OPTION
START_TEST

