#!/bin/bash

KEEP_GO=1
WAIT_SECS=3

playback() {
	while [ $KEEP_GO = 1 ]
	do
#		gst-play-1.0 ./resources/Melody.mp3
#		gst-play-1.0 ./resources/lovenotfull.wav
		aplay ./resources/lovenotfull.wav
		sleep $WAIT_SECS
	done
}

catchSignal() {
	KEEP_GO=0
	echo "Stopping the shell script...";
}

trap "catchSignal" 2

playback

echo "Finish stopping the shell script..."
