#!/bin/bash
### parameter
socket_name_1=canfd0
socket_name_2=canfd1
dev_name=ttyACM0
baudrate=7 # 0~3: support FW version >= 03.00
           # 0: 5   KBPS, 1: 10  KBPS,  2: 20  KBPS, 3: 50  KBPS,
           # 4: 100 KBPS, 5: 125 KBPS,  6: 250 KBPS, 7: 500 KBPS,
           # 8: 800 KBPS, 9: 1 MBPS,   A: 400 KBPS
datarate=2 # 2: 2 MBPS, 4: 4 MBPS,  5: 5 MBPS, 6: 6 MBPS
FDF_1=1 # 0: DISABLE CAN1 FD mode (aka CAN2.0B only), 1:ENABLE CAN1 FD mode (downward compatibility CAN2.0B)
FDF_2=1 # 0: DISABLE CAN2 FD mode (aka CAN2.0B only), 1:ENABLE CAN2 FD mode (downward compatibility CAN2.0B)
error_type=0 # 0: EMUC_DIS_ALL, 1: EMUC_EE_ERR, 2: EMUC_BUS_ERR, 3: EMUC_EN_ALL
### bit timing configuration
bit_timing_en=0 # 0: DISABLE bit timing configuration, 1: ENABLE bit timing configuration
# if you want to use bit timing config, please enable bit_timing_en and set the below baudrate
if [ ${bit_timing_en} -eq 1 ]; then
    baudrate=B # B: CUSTOM_OPT_0, C: CUSTOM_OPT_1
fi

### step
sudo pkill -2 emucd_64
sleep 0.2
sudo rmmod emuc2socketcan
# sudo insmod emuc2socketcan.ko
# sudo cp emuc2socketcan.ko /lib/modules/$(uname -r)/kernel/drivers/net/can
# sudo depmod -a
sudo modprobe emuc2socketcan

if [ ${bit_timing_en} -eq 1 ]; then
    sudo ./emucd_64 -s${baudrate} -T0 ${dev_name} # setup timing config
fi
sudo ./emucd_64 -f${FDF_1}${FDF_2} -d${datarate} -s${baudrate} -e${error_type} ${dev_name} ${socket_name_1} ${socket_name_2}

if command -v ifconfig &> /dev/null
then
    sudo ifconfig ${socket_name_1} txqueuelen 1000
    sudo ifconfig ${socket_name_2} txqueuelen 1000
    sudo tc qdisc add dev ${socket_name_1} root handle 1: pfifo
    sudo tc qdisc add dev ${socket_name_2} root handle 1: pfifo
    sudo ifconfig ${socket_name_1} up
    sudo ifconfig ${socket_name_2} up
elif command -v ip &> /dev/null
then
    sudo ip link set ${socket_name_1} txqueuelen 1000
    sudo ip link set ${socket_name_2} txqueuelen 1000
    sudo tc qdisc add dev ${socket_name_1} root handle 1: pfifo
    sudo tc qdisc add dev ${socket_name_2} root handle 1: pfifo
    sudo ip link set ${socket_name_1} up
    sudo ip link set ${socket_name_2} up
else
    echo "ip & ifconfig command could not be found"
fi
