#!/bin/bash

# cd /usr/local/cuda/samples 
# make
#/usr/local/cuda/samples/bin/aarch64/linux/release/nbody_opengles -fp64
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'
COUNT=1

trap cleanup EXIT

function cleanup {
        echo -e "${RED} GPU STRESS STOP!${NC}"
}


./bin/matrixMulCUBLAS -sizemult=8
