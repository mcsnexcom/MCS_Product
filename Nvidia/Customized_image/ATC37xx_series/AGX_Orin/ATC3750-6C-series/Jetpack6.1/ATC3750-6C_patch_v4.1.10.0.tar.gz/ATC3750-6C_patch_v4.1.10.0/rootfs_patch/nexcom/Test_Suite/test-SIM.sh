#!/bin/bash
PRODUCT="`tr -d '\0' < /proc/device-tree/product`"
MCU_CMD="$(pwd)/MCU/send_MCU_Cmd.sh"
if [[ $PRODUCT =~ ^ATC3750 ]]; then
	MCU_DEV="/dev/ttyTHS4"
elif [[ $PRODUCT =~ ^ATC35 ]]; then
	MCU_DEV="/dev/ttyTHS1"
fi
TMP=`grep -n "MCU_DEV=" $MCU_CMD | awk -F ':' '{print $1}'`
sed -i "${TMP}c MCU_DEV=\"${MCU_DEV}\"" $MCU_CMD

RED='\033[0;31m'
WHITE='\033[1;37m'
LGREEN='\033[1;32m'
NC='\033[0m' # No Color

#/bin/stty -F /dev/ttyTHS1 115200 -echo -echoe -echok raw

#cat /dev/ttyTHS1 > tmp.log &
cat $MCU_DEV > tmp.log &
sleep 0.1
if [[ $PRODUCT =~ ^ATC3750 ]]; then
	bash $MCU_CMD 00 02 2D 00
elif [[ $PRODUCT =~ ^ATC35 ]]; then
	bash $MCU_CMD 00 02 2D
fi
#echo -e "\xF1\x00\x02\x2D\x30\xF2" > /dev/ttyTHS1
sync
kill -9 `ps | grep "cat" | grep -v grep | awk '{print $1}'` > /dev/null 2>&1
TMP_DATA="`hexdump -C tmp.log | head -n 1 | awk '{print $6}'`"
#echo $TMP_DATA
if [ "$TMP_DATA" == "00" ]; then
	echo -e "${LGREEN}[NOW] SIM card 1${NC}"

elif [ "$TMP_DATA" == "01" ]; then
	echo -e "${LGREEN}[NOW] SIM card 2${NC}"
		
else
	echo -e "${LRED}error!${NC}"
fi
rm -f tmp.log

read -p "Input SIM card 1/2/N(exit) :" SIM

if [ "$SIM" == "1" ]; then
	echo -e "${LGREEN}Selected SIM 1.${NC}"
	#cat /dev/ttyTHS1 > tmp.log &
	cat $MCU_DEV > tmp.log &
	sleep 0.1
	if [[ $PRODUCT =~ ^ATC3750 ]]; then
		bash $MCU_CMD 00 03 2D 00 00
	elif [[ $PRODUCT =~ ^ATC35 ]]; then
		bash $MCU_CMD 00 03 2D 00
	fi
	#echo -e "\xF1\x00\x03\x2D\x00\x44\xF2" > /dev/ttyTHS1
	sync
	kill -9 `ps | grep "cat" | grep -v grep | awk '{print $1}'` > /dev/null 2>&1
	TMP_DATA="`hexdump -C tmp.log | head -n 1 | awk '{print $6}'`"
	#echo $TMP_DATA
	
	if [ "$TMP_DATA" == "01" ]; then
		echo -e "${LGREEN}Selected Success!${NC}"
	else
		echo -e "${LRED}Selected Fail!${NC}"
	fi


elif [ "$SIM" == "2" ]; then
	echo -e "${LGREEN}Selected SIM 2.${NC}"
	#cat /dev/ttyTHS1 > tmp.log &
	cat $MCU_DEV > tmp.log &
        sleep 0.1
	if [[ $PRODUCT =~ ^ATC3750 ]]; then
		bash $MCU_CMD 00 03 2D 00 01
	elif [[ $PRODUCT =~ ^ATC35 ]]; then
		bash $MCU_CMD 00 03 2D 01
	fi
        #echo -e "\xF1\x00\x03\x2D\x01\x1E\xF2" > /dev/ttyTHS1
	sync
	kill -9 `ps | grep "cat" | grep -v grep | awk '{print $1}'` > /dev/null 2>&1
	TMP_DATA="`hexdump -C tmp.log | head -n 1 | awk '{print $6}'`"
	#echo $TMP_DATA

        if [ "$TMP_DATA" == "01" ]; then
                echo -e "${LGREEN}Selected Success!!${NC}"
        else
                echo -e "${LRED}Selected Fail!${NC}"
        fi


else
	echo "Exit!"
fi
rm -f tmp.log

