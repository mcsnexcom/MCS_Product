#!/bin/bash

# Setting the ip tables and route tables
# Ethernet 1
ETH0_IP=10.50.0.1
ETH0_FAKE_IP=10.60.0.1
# Ethernet 2
ETH1_IP=10.50.1.1
ETH1_FAKE_IP=10.60.1.1

# Wlan 1
WLAN0_IP=1.1.1.1
WLAN0_FAKE_IP=1.1.1.1

PRODUCT_NAME="$2"
ETH="$1"
ETH_IP=""
POE_IP=""
ETH_IP="172.20.0.1"
POE_IP="172.30.0.1"
if [ "$2" = "ATC3530" ]; then
	ETH_BUS="2490000"
	POE_BUS="14160000.pcie"
elif [ "$2" = "ATC3540" ] ||  [ "$2" = "ATC3520" ] || [[ "$2" = ATC3560* ]] || [[ "$2" = ATC3563* ]]; then
	ETH_BUS="140a0000"
	POE_BUS="14100000.pcie"
elif [ "$2" = "ATC3750" ]; then
	ETH_BUS="6810000.ethernet"
	POE_BUS="2310000.ethernet"
elif [ "$2" = "ATC3750-8M" ]; then
	ETH_BUS="2310000.ethernet"
	POE_BUS="141a0000.pcie"
elif [ "$2" = "X80" ]; then
	ETH_BUS="140a0000.pcie"
	POE_BUS="14100000.pcie"
	POE_BUS_2="141e0000.pcie"
	POE_BUS_3="140c0000.pcie"
	POE2_IP="172.40.0.1"
	POE3_IP="172.50.0.1"
	# Setting the ip tables and route tables
	# Ethernet 3
	ETH2_IP=10.70.0.1
	ETH2_FAKE_IP=10.80.0.1
	# Ethernet 4
	ETH3_IP=10.70.1.1
	ETH3_FAKE_IP=10.80.1.1
elif [ "$2" = "ATC3521" ] || [ "$2" = "ATC3541" ] || [[ "$2" = ATC3561* ]]; then
	POE_BUS="140a0000.pcie"
fi


echo "start"
ETH_NM="`ls -l /sys/class/net/ | grep "$ETH_BUS" | grep enP | awk -F / '{print $NF}'`"
POE_NM="`ls -l /sys/class/net/ | grep "$POE_BUS" | grep enP | awk -F / '{print $NF}'`"
ETH_MAC="`sudo ifconfig $ETH_NM | grep ether | awk '{print $2}'`"
POE_MAC="`sudo ifconfig $POE_NM | grep ether | awk '{print $2}'`"

ETH0_MAC=""
ETH1_MAC=""

showUsage() {
	echo "USAGE: sh set-Ethernet.sh {options}"
	echo "{options}"
	echo "  h help, list usage"
	echo "  e setting ip for external ping test"
	echo "  i setting ip for internal ping test"
}

setIP() {
	if [ "$ETH" = "e" ]; then			# external internet
		echo "ETH NM : $ETH_NM"
		echo "POE NM : $POE_NM"
		echo "ETH IP : $ETH_IP"
		echo "POE IP : $POE_IP"
		sudo ifconfig ${ETH_NM} "${ETH_IP}/24"
		sudo ifconfig ${POE_NM} "${POE_IP}/24"
		if [ "$PRODUCT_NAME" = "X80" ]; then
			ETH2_NM="$(ls -l /sys/class/net/ | grep "$POE_BUS_2" | grep enP | awk -F / '{print $NF}')"
			ETH3_NM="$(ls -l /sys/class/net/ | grep "$POE_BUS_3" | grep enP | awk -F / '{print $NF}')"
			sudo ifconfig $ETH2_NM $POE2_IP/24
			sudo ifconfig $ETH3_NM $POE3_IP/24
			#ETH2_MAC="`sudo ifconfig $ETH2_NM | grep ether | awk '{print $2}'`"
			#ETH3_MAC="`sudo ifconfig $ETH3_NM | grep ether | awk '{print $2}'`"
			# echo "[Debug]: ETH2_MAC=$ETH2_MAC"
			# echo "[Debug]: ETH3_MAC=$ETH3_MAC"
		fi
	elif [ "$ETH" = "i" ]; then			# internal internet
		ETH0_NM="$(ls -l /sys/class/net/ | grep "$ETH_BUS" | grep enP | awk -F / '{print $NF}')"
		ETH1_NM="$(ls -l /sys/class/net/ | grep "$POE_BUS" | grep enP | awk -F / '{print $NF}')"
		sudo ifconfig $ETH0_NM $ETH0_IP/24
	        sudo ifconfig $ETH1_NM $ETH1_IP/24
		ETH0_MAC="`sudo ifconfig $ETH0_NM | grep ether | awk '{print $2}'`"
		ETH1_MAC="`sudo ifconfig $ETH1_NM | grep ether | awk '{print $2}'`"
		if [ "$PRODUCT_NAME" = "X80" ]; then
			ETH2_NM="$(ls -l /sys/class/net/ | grep "$POE_BUS_2" | grep enP | awk -F / '{print $NF}')"
			ETH3_NM="$(ls -l /sys/class/net/ | grep "$POE_BUS_3" | grep enP | awk -F / '{print $NF}')"
			sudo ifconfig $ETH2_NM $ETH2_IP/24
			sudo ifconfig $ETH3_NM $ETH3_IP/24
			ETH2_MAC="`sudo ifconfig $ETH2_NM | grep ether | awk '{print $2}'`"
			ETH3_MAC="`sudo ifconfig $ETH3_NM | grep ether | awk '{print $2}'`"
			# echo "[Debug]: ETH2_MAC=$ETH2_MAC"
			# echo "[Debug]: ETH3_MAC=$ETH3_MAC"
		fi
	fi

}

setRouteAndIPTables() {
        # nat source IP 10.50.0.1 -> 10.60.0.1 when going to 10.60.1.1
        sudo iptables -t nat -A POSTROUTING -s $ETH0_IP -d $ETH1_FAKE_IP -j SNAT --to-source $ETH0_FAKE_IP

        # nat inbound 10.60.0.1 -> 10.50.0.1
        sudo iptables -t nat -A PREROUTING -d $ETH0_FAKE_IP -j DNAT --to-destination $ETH0_IP

        # nat source IP 10.50.1.1 -> 10.60.1.1 when going to 10.60.0.1
        sudo iptables -t nat -A POSTROUTING -s $ETH1_IP -d $ETH0_FAKE_IP -j SNAT --to-source $ETH1_FAKE_IP

        # nat inbound 10.60.1.1 -> 10.50.1.1
        sudo iptables -t nat -A PREROUTING -d $ETH1_FAKE_IP -j DNAT --to-destination $ETH1_IP

        sudo ip route add $ETH1_FAKE_IP dev $ETH0_NM
        sudo arp -i $ETH0_NM -s $ETH1_FAKE_IP $ETH1_MAC # eth1's mac address

        sudo ip route add $ETH0_FAKE_IP dev $ETH1_NM
        sudo arp -i $ETH1_NM -s $ETH0_FAKE_IP $ETH0_MAC # eth0's mac address

		# In X80 condition
		if [ "$PRODUCT_NAME" = "X80" ]; then
			# nat source IP 10.70.0.1 -> 10.80.0.1 when going to 10.80.1.1
			sudo iptables -t nat -A POSTROUTING -s $ETH2_IP -d $ETH3_FAKE_IP -j SNAT --to-source $ETH2_FAKE_IP

			# nat inbound 10.80.0.1 -> 10.70.0.1
			sudo iptables -t nat -A PREROUTING -d $ETH2_FAKE_IP -j DNAT --to-destination $ETH2_IP

			# nat source IP 10.70.1.1 -> 10.80.1.1 when going to 10.80.0.1
			sudo iptables -t nat -A POSTROUTING -s $ETH3_IP -d $ETH2_FAKE_IP -j SNAT --to-source $ETH3_FAKE_IP

			# nat inbound 10.80.1.1 -> 10.70.1.1
			sudo iptables -t nat -A PREROUTING -d $ETH3_FAKE_IP -j DNAT --to-destination $ETH3_IP

			sudo ip route add $ETH3_FAKE_IP dev $ETH2_NM
			sudo arp -i $ETH2_NM -s $ETH3_FAKE_IP $ETH3_MAC # eth3's mac address

			sudo ip route add $ETH2_FAKE_IP dev $ETH3_NM
			sudo arp -i $ETH3_NM -s $ETH2_FAKE_IP $ETH2_MAC # eth2's mac address
		fi
}


execCMD() {
	if [ $# -ge 1 ]; then
  		case $1 in
			"h")
				showUsage
			;;
			"e")
				ETH_IP=172.20.0.1
				POE_IP=172.30.0.1
				setIP
			;;
			"i") 
				setIP
				setRouteAndIPTables
			;;
		esac
  	else
		showUsage
	fi
	
	return 0
}

execCMD $*
