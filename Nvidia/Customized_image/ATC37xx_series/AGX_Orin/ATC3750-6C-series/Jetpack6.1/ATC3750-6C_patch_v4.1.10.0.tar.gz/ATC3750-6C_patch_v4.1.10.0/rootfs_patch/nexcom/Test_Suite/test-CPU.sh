#!/bin/bash

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'
COUNT=1
THREAD=$(nproc)

trap cleanup EXIT

function cleanup {
        echo -e "${RED} CPU STRESS STOP!${NC}"
}


while true 
do
	echo -e "${GREEN}CPU STRESS TESTING...${NC}[$COUNT] "
	stress --cpu $((THREAD-1)) --timeout 20s
	#stress --cpu 6 --timeout 20s
	#sleep 10
	COUNT=$(( COUNT + 1 ))
done


