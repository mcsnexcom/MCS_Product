#!/bin/bash

KEEP_GO=1
DATA=""
NUM=0
IDX=1
WAIT_SECS=1

### Counter {
COUNT_PASS=0
COUNT_FAIL=0
###}


revGPS() {
	while [ $KEEP_GO = 1 ]
	do
		DATA=`cat /dev/ttyACM0 | head -n 10`
		DATA=`echo "$DATA" | grep -i "GNGSA" | head -n 1`
		if [ ! "$DATA" = "" ];
		then
			echo ""
			echo $DATA
			echo "--------------------------------"
			DATA=`echo "$DATA" | cut -d ',' -f 4,5,6,7,8,9,10,11,12,13,14,15`
			while [ $IDX -le 12 ] 
			do
				NUM=`echo "$DATA" | sed 's/,,/,/g'`
				IDX=`expr $IDX + 1`
			done
			NUM=`echo "$DATA" | sed 's/,/ /g' | wc -w`
			echo "The number of satellites is $NUM"
			echo ""
			if [ $NUM -gt 0 ]; then
				COUNT_PASS=$(( COUNT_PASS + 1))
				echo -e "\033[32mGPS test PASS\033[0m[$COUNT_PASS]\n"
			else
				COUNT_FAIL=$(( COUNT_FAIL + 1))
				echo -e "\033[31mGPS test FAIL\033[0m[$COUNT_FAIL]\n"
			fi
		fi
		DATA=""
		sleep $WAIT_SECS
	done
}

catchSignal() {
	KEEP_GO=0
	echo "Stopping the shell script...";
}

trap "catchSignal" 2

stty -F /dev/ttyACM0 9600
revGPS

echo "Finish stopping the shell script..."
