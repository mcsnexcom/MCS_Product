#!/bin/bash

# Remove service from rc.d
sudo update-rc.d -f run_emucd remove

# Remove files
sudo rm -f /usr/sbin/emucd_64
sudo rm -f /etc/init.d/run_emucd
