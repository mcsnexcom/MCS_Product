#!/bin/bash

# For Ubuntu

KEEP_GO=1
WAIT_SECS=3
COUNT_PASS=0
COUNT_FAIL=0
INTERFACE="`basename "$(ls -l /sys/class/net | grep $1)"`"
echo "interface=$INTERFACE"
catHTML() {
	while [ $KEEP_GO = 1 ]
		do
		wget http://www.google.com
		cat index.html | awk -F " " '{print $1}'
		rm -f index.html
		sleep 3
	done
}

pingIP() {
        while [ $KEEP_GO = 1 ]
        do
                RESULT="`ping -c 1 $1`"
                echo "$RESULT"
                TMP_DATA=`echo "$RESULT" | grep ' 0% packet loss'`
                if [ "$TMP_DATA" != "" ]; then
			COUNT_PASS=$(( $COUNT_PASS + 1 ))
                        echo -e "\033[32mWifi Ping test PASS\033[0m [$COUNT_PASS]\n"
                else
			COUNT_FAIL=$(( $COUNT_FAIL + 1 ))
                        echo -e "\033[31mWifi Ping test FAIL\033[0m [$COUNT_FAIL]\n"
                fi
                sleep $WAIT_SECS
        done
}

#pingIP() {
#	while [ $KEEP_GO = 1 ]
#	do
#		ping -c 1 $1
#		sleep $WAIT_SECS
#	done
#}

actWIFI() {
	read -p $'\e[33mInput Wi-Fi SSID : \e[0m' SSID
	read -p $'\e[33mInput Wi-Fi Password : \e[0m' PASSWD
	read -p $'\e[33mInput Target IP : \e[0m' IP
	#sudo killall wpa_supplicant
	sudo pkill -f "wpa_supplicant -B -i ${INTERFACE}"
	#wpa_passphrase "${SSID}" "${PASSWD}" | sudo tee /etc/wpa_supplicant.conf
	if [ -n "${PASSWD}" ]; then
		wpa_passphrase "${SSID}" "${PASSWD}" | sudo tee /etc/wpa_supplicant.conf > /dev/null
	else
		echo "network={
		ssid=\"$SSID\"
		key_mgmt=NONE
		}" | sudo tee /etc/wpa_supplicant.conf > /dev/null
	fi
	sudo wpa_supplicant -B -i ${INTERFACE} -c /etc/wpa_supplicant.conf
	dhclient ${INTERFACE}
	# ifconfig wlan0 192.168.0.10 netmask 255.255.255.0
	# iwconfig wlan0 essid "$SSID"
	if [ -n "${IP}" ]; then
		pingIP ${IP}
	else
		GATEWAY="`ip route | grep via | grep ${INTERFACE} |awk -F " " '{print $3}'`"
		pingIP ${GATEWAY}
	fi
}

catchSignal() {
	KEEP_GO=0
	echo "Stopping the shell script...";
}

trap "catchSignal" 2

actWIFI $1 $2 # arg1:which device 0:wlan0|1:wlan1 ; arg2:IP

echo "Finish stopping the shell script..."
