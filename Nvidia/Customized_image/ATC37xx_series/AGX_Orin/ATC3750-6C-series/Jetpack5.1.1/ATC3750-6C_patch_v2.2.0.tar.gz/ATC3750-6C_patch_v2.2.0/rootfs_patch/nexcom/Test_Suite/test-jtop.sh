#!/bin/bash
jtop
