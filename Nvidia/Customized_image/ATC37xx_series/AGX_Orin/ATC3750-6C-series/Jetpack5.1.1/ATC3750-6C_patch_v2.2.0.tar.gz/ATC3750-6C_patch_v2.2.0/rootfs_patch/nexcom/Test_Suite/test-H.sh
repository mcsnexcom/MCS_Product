#!/bin/bash

# For Ubuntu

KEEP_GO=1
WAIT_SECS=3
CNT=1
C_CNT=5000
COLOR=1

showH() {
	while [ $KEEP_GO = 1 ]
	do
		#echo -en "\e[38;5;${COLOR}m"
		echo -n "H"
		if [ $CNT -gt $C_CNT ]; then
			sleep $WAIT_SECS #for Ubuntu; s - seconds, m - minutes, h - hours, d - days
		else
			CNT=`expr $CNT + 1`
		fi

		COLOR=$(( $COLOR + 1 ))
		
		if [ $COLOR == 256 ]; then
			COLOR=1
		fi
	done
}

catchSignal() {
	KEEP_GO=0
	echo "Stopping the shell script...";
}

trap "catchSignal" 2

showH

echo "Finish stopping the shell script..."
