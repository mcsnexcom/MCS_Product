#!/bin/bash

RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color
COLOR=''

FUN_PASS=0
FUN_FAIL=1
RESULT=$FUN_PASS

USER="`logname`"
# if the user is not root, there is not point in going forward
THISUSER="`whoami`"

PRODUCT=$(tr -d '\0' < /proc/device-tree/product)
CHK_PRODUCT="ATC3750-8M"

DTB_DIR="/boot/dtb/"
_DTB="FDT \/boot\/dtb\/kernel_tegra234-%s-atc3750-8M-%s.dtb"

# default dtb
DEF_DTB=""

# modify dtb
MOD_DTB=""

# dtb file name
_F_DTB="tegra234-%s-atc3750-8M-%s.dtb"

# replace dtb file name
RPL_DTB="kernel_"
ORI_DTB=""

DEF_CAMERA=""

_MODULE=""

CAM_ARRAY=( "N/A" "sturdecam21" "sturdecam25" "sturdecam31" )

CHK_USER(){
	if [ "x$THISUSER" != "xroot" ]; then
		echo -e "${RED}This script requires root privilege.${NC}"
    		exit $FUN_FAIL
	fi
	return $FUN_PASS
}

# Check enviroment
CHK_ENV(){
	if [ "$PRODUCT" == "$CHK_PRODUCT" ]; then
		MEM="`free -g | grep Mem | awk -F " " '{print $2}'`"
		if [ $MEM -gt 0 -a $MEM -le 32 ]; then
		##	"AGX Orin 32G"
			_MODULE="p3701-0004"
		else
		##	"AGX Orin 64G"
			_MODULE="p3701-0005"
		fi
		if [ `ls $DTB_DIR | wc -l` -eq 1 ]; then
			DEF_CAMERA="`ls $DTB_DIR | awk -F "-" '{print $NF}' | awk -F "." '{print $1}'`"
		else
			echo -e "${RED}Check original dtb file failed, check '$DTB_DIR' only have one dtb file!!${NC}"
			return $FUN_FAIL
		fi

	else
		echo -e "${RED}This script only support Product : $CHK_PRODUCT${NC}"
		return $FUN_FAIL
	fi
	return $FUN_PASS
}

CHK_REBOOT(){
	echo -ne "${YELLOW}WARNING!! Relpace gmsl2 camera need power-off, shut down system now? (y/N)${NC}"
	read -p "" YN
	if [ "${YN^^}" = "Y" ]; then
		echo -e "${GREEN}shut down system...${NC}"
		sleep 1
		shutdown -h now

	elif [ "${YN^^}" = "N" ]; then
		echo -e "${YELLOW}Manually shut down by user!${NC}"
	else
		echo -e "${RED}Invalid input!!${NC}"
		exit
	fi
	return $FUN_PASS
}

MENU(){	
	echo -e "${RED}***************************************************************${NC}"
	echo -e "${RED}*            DO NOT use Ctrl+C to stop this script            *${NC}"
	echo -e "${RED}*                 (Input '0' to exit script)                  *${NC}"
	echo -e "${RED}***************************************************************${NC}"
	echo -e "${RED}*                                                             *${NC}"
	echo -e "${RED}* [1]:'STURDeCAM21'   [2]:'STURDeCAM25'   [3]:'STURDeCAM31'   *${NC}"
	echo -e "${RED}*                                                             *${NC}"
	echo -e "${RED}***************************************************************${NC}"
	echo 
	echo -en "${GREEN}Which camera are you currently using?:${NC}"
	read -p "" _CAMERA
	if [[ "$_CAMERA" =~ ^[0-9]+$ ]]; then
		if [ $_CAMERA -eq 0 ]; then
			echo -e "${RED}exit${NC}"
			exit
		else
			CAMERA="${CAM_ARRAY[${_CAMERA}]}"
		fi
	else
		echo -e "${RED}Invalid input!!${NC}"
		return $FUN_FAIL
	fi
	return $FUN_PASS
}

REPLACE_DTB(){
	DEF_DTB="`printf "${_DTB}" "${_MODULE}" "${DEF_CAMERA}"`"
	MOD_DTB="`printf "${_DTB}" "${_MODULE}" "${CAMERA}"`"
	ORI_DTB="`printf "${_F_DTB}" "${_MODULE}" "${CAMERA}"`"
	RPL_DTB+="`printf "${_F_DTB}" "${_MODULE}" "${CAMERA}"`"
	if [ `ls $DTB_DIR | wc -l` -eq 1 ]; then
		rm $DTB_DIR/*
	fi
	if [ -e "/boot/${ORI_DTB}" ]; then
		cp -af /boot/${ORI_DTB} $DTB_DIR/$RPL_DTB
		if [ $? -eq $FUN_PASS ]; then
			echo -e "${GREEN}Copy '${RPL_DTB}' to '${DTB_DIR}' directory success!${NC}"
			sed -i "s/${DEF_DTB}/${MOD_DTB}/g" /boot/extlinux/extlinux.conf
		fi
	fi
	return $FUN_PASS
}

# Main Start
CHK_USER
if [ $? -eq $FUN_PASS ]; then
	CHK_ENV
	if [ $? -eq $FUN_PASS ]; then
		MENU
		if [ $? -eq $FUN_PASS ]; then
			REPLACE_DTB
			if [ $? -eq $FUN_PASS ]; then
				CHK_REBOOT
			fi
		fi
	fi
fi

