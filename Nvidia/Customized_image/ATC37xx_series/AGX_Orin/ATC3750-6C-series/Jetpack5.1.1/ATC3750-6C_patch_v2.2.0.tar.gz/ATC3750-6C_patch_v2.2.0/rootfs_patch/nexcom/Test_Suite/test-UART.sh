#!/bin/bash

KEEP_GO=1
WAIT_SECS=3
COUNT_PASS=0
COUNT_FAIL=0
COM_REAL=""
if [[ $1 =~ ^ttyTHS[0-9]$ ]]; then
	COM_REAL=$1
else
	#COM_REAL="`dmesg | grep "$1" | grep -oP "tty[USB|THS]{3}[0-9]{1}"`"
	COM_REAL="`ls -l /sys/class/tty/ | grep "$1" | awk -F / '{print $NF}'`"
fi
loopBack() {
	while [ $KEEP_GO = 1 ]
	do
		#if [ "$1" == "ttyUSB0" ];then
		#	DETECTUSB=`ls /sys/devices/3610000.xhci/usb1/1-2/1-2.3/1-2.3:1.0/ | grep tty`
		#	RESULT="`./bin/uart t /dev/$DETECTUSB`"
		#else
		#	RESULT="`./bin/uart t /dev/$1`"
		#fi
		RESULT="`./bin/uart t /dev/$COM_REAL`"
		
		echo "$RESULT"
		TMP_DATA=`echo "$RESULT" | grep ' is test,'`
		if [ "$TMP_DATA" != "" ]; then
			COUNT_PASS=$(( $COUNT_PASS + 1 ))
			echo -e "\033[32mUART test PASS\033[0m [$COUNT_PASS]\n"
		else
			COUNT_FAIL=$(( $COUNT_FAIL + 1 ))
			echo -e "\033[31mUART test FAIL\033[0m [$COUNT_FAIL]\n"
		fi
		sleep $WAIT_SECS 
	done
}

catchSignal() {
	KEEP_GO=0
	echo "Stopping the shell script...";
}

trap "catchSignal" 2

export LD_LIBRARY_PATH=./lib
loopBack $1

echo "Finish stopping the shell script..."
