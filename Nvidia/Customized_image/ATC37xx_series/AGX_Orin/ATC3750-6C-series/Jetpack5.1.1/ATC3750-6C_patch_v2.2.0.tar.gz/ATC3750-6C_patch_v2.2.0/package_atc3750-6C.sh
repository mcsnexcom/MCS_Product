#!/bin/bash
# if the user is not root, there is not point in going forward
THISUSER=`whoami`
if [ "x$THISUSER" != "xroot" ]; then
    echo "This script requires root privilege"
    exit 1
fi

if [ ! -e rootfs/etc/image_version ]; then
	touch rootfs/etc/image_version
	echo -e "IMG_VERSION" > rootfs/etc/image_version
fi
_VERSION=v2.2.0

#ATC3750 32G
VERSION="${_VERSION}_6C_AGX_ORIN_32G"
sed -i "1s/.*/${VERSION}/" rootfs/etc/image_version
#ATC3750_mfi_v2.2.0_AGX_ORIN_32G.tar.gz

#offline mode
sudo PACKAGE_NAME=ATC3750-6C_mfi_$VERSION BOARDID=3701 FAB=500 BOARDSKU=0004 BOARDREV=M.0 ./tools/kernel_flash/l4t_initrd_flash.sh --no-flash --massflash 5 atc3750-orin mmcblk0p1
#online mode
#sudo PACKAGE_NAME=ATC3750_mfi_$VERSION  ./tools/kernel_flash/l4t_initrd_flash.sh --no-flash --massflash 1 atc3750-orin mmcblk0p1

#ATC3750 64G
VERSION="v2.2.0_6C_AGX_ORIN_64G"
sed -i "1s/.*/${VERSION}/" rootfs/etc/image_version
#ATC3750_mfi_v2.2.0_AGX_ORIN_64G.tar.gz

#offline mode
sudo PACKAGE_NAME=ATC3750-6C_mfi_$VERSION BOARDID=3701 FAB=500 BOARDSKU=0005 BOARDREV=M.0 ./tools/kernel_flash/l4t_initrd_flash.sh --no-flash --massflash 5 atc3750-orin mmcblk0p1
#online mode
#sudo PACKAGE_NAME=ATC3750_mfi_$VERSION  ./tools/kernel_flash/l4t_initrd_flash.sh --no-flash --massflash 1 atc3750-orin mmcblk0p1


########## External Storage ########

# AGX Orin 32G External Storage
#VERSION="${_VERSION}_6C_AGX_ORIN_32G_NVMe"
#sed -i "1s/.*/${VERSION}/" rootfs/etc/image_version

#sudo ADDITIONAL_DTB_OVERLAY_OPT="BootOrderNvme.dtbo" PACKAGE_NAME=ATC3750-6C_mfi_${VERSION} \
#    BOARDID=3701 FAB=500 BOARDSKU=0004 BOARDREV=M.0 \
#    ./tools/kernel_flash/l4t_initrd_flash.sh --no-flash --external-device nvme0n1p1 \
#    -p "-c bootloader/t186ref/cfg/flash_t234_qspi.xml --no-systemimg" \
#    -c ./tools/kernel_flash/flash_l4t_external.xml \
#    --massflash 5 --showlogs --network usb0 \
#    atc3750-orin nvme0n1p1

# AGX Orin 64G External Storage
#VERSION="${_VERSION}_6C_AGX_ORIN_64G_NVMe"
#sed -i "1s/.*/${VERSION}/" rootfs/etc/image_version

#sudo ADDITIONAL_DTB_OVERLAY_OPT="BootOrderNvme.dtbo" PACKAGE_NAME=ATC3750-6C_mfi_${VERSION} \
#    BOARDID=3701 FAB=500 BOARDSKU=0005 BOARDREV=M.0 \
#    ./tools/kernel_flash/l4t_initrd_flash.sh --no-flash --external-device nvme0n1p1 \
#    -p "-c bootloader/t186ref/cfg/flash_t234_qspi.xml --no-systemimg" \
#    -c ./tools/kernel_flash/flash_l4t_external.xml \
#    --massflash 5 --showlogs --network usb0 \
#    atc3750-orin nvme0n1p1

