#!/bin/bash

# For Ubuntu

KEEP_GO=1

playback() {
	# for ubuntu(need to install SMPlayer)
	smplayer -fullscreen ./resources/color_bar2.mp4
}

catchSignal() {
	KEEP_GO=0
	echo "Stopping the shell script...";
}

#trap "catchSignal" 2

playback

echo "Finish stopping the shell script..."
