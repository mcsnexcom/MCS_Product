#!/bin/bash

### Global Variables ###

OFF=0;ON=1;
WAIT_SEC=5

FUN_PASS=0
FUN_FAIL=1

MCU_DEV=""
MCU_DEV_ATC3530="/dev/ttyTHS1"
MCU_DEV_ATC3750="/dev/ttyTHS4"

PRODUCT=$(tr -d '\0' < /proc/device-tree/product)

AQR113C_STAT=0
CONST_AQR113C="eth1"
ETH_CONF="/etc/NetworkManager/NetworkManager.conf"

### Global Variables ###

chkProduct() {
	#check product name
	case "$PRODUCT" in
		ATC35*) MCU_DEV=$MCU_DEV_ATC3530
		;;
		ATC3750*) MCU_DEV=$MCU_DEV_ATC3750
		;;
	esac
	
	return $FUN_PASS
}

osState() {
	if [ ! -e $MCU_DEV ]; then
		exit -1
	else
		/bin/stty -F $MCU_DEV 115200 raw -echo -echoe -echok
	fi
	sleep $WAIT_SEC
	#turn on OS status LED 
	echo -e "\xF1\xE0\x03\x14\x02\x1E\xF2" > $MCU_DEV

	return $FUN_PASS
}

# disable all ethernet eee function
disable_eth_eee() {
	for ETH in `find /sys/devices/platform -regextype sed -regex ".*/eth[0-9]\{1\}" | awk -F/ '{print $NF}'`
	do
	if [ "$ETH" == "eth0" -a "$PRODUCT" == "ATC3750" ]; then # ignore KSZ9477 set eee off
		continue;
	fi
	if [ "$PRODUCT" == "ATC3750" ]; then
		TMP="`ifconfig eth1 up`"
		if [ "$?" == "$FUN_PASS" ]; then
			AQR113C_STAT=1
		fi
	fi
        	ethtool --set-eee $ETH eee off
		ethtool -s $ETH wol d
	done	            
	return $FUN_PASS
}

BT() {
    #BT off
    echo -e "\xf1\x00\x03\x17\x00\x30\xf2" > $MCU_DEV
    sleep 1
    #BT on
    echo -e "\xf1\x00\x03\x17\x01\x6A\xf2" > $MCU_DEV
	return $FUN_PASS
}

chkGPS() {
    #2 ports POE version only: ATC3530-IP7-4MP
    stty -F "/dev/ttyACM0"
    if [ $? -eq $FUN_PASS ]; then
            sleep 0.1
            echo -e "\xF1\xE0\x03\x18\x01\x70\xF2" > $MCU_DEV
    else
            sleep 0.1
            echo -e "\xF1\xE0\x03\x18\x00\x2A\xF2" > $MCU_DEV
    fi
	return $FUN_PASS
}

USB() {
	# USB on
	if [ "$1" == "$ON" ]; then
		echo -e "\xF1\x00\x03\x19\x01\x1C\xF2" > $MCU_DEV
	elif [ "$1" == "$OFF" ]; then
		if [ "$PRODUCT" == "ATC3750" ]; then 
			echo -e "\xF1\x00\x03\x19\x05\x2E\xF2" > $MCU_DEV
		elif [ "$PRODUCT" == "ATC3750-8M" ]; then
			echo -e "\xF1\x00\x03\x19\x00\x46\xF2" > $MCU_DEV
		fi
	fi
	return $FUN_PASS
}

aqr113c_setting() {
    TMP="`grep "\[keyfile\]" ${ETH_CONF}`"
    if [ ! "$?" -eq "$FUN_PASS" ]; then
		echo -e "" >> ${ETH_CONF}
		echo -e "#[keyfile]" >> ${ETH_CONF}
    fi
    TMP="`grep "unmanaged" ${ETH_CONF}`"
    if [ ! "$?" -eq "$FUN_PASS" ]; then
		echo -e "#unmanaged-devices=interface-name:${CONST_AQR113C}" >> ${ETH_CONF}
    fi
	case $1 in
            "$ON")
		#set 10G eth LED register
                /usr/local/bin/phytool write ${CONST_AQR113C}/0:30/0xc430 0xc0ef
                /usr/local/bin/phytool write ${CONST_AQR113C}/0:30/0xc431 0x0080
                /usr/local/bin/phytool write ${CONST_AQR113C}/0:30/0xc432 0xc040
                # ATC3750 AQR113C(10G PHY), enable ethernet interface.
		TMP="`grep "\#\[keyfile\]" ${ETH_CONF}`"
		if [ "$TMP" != "#[keyfile]" ]; then	
			sed -i -e '/unmanaged/s/^/#/' -e '/\[keyfile\]/s/^/#/' ${ETH_CONF}
		fi
            ;;
            "$OFF")
		TMP="`grep "\#\[keyfile\]" ${ETH_CONF}`"
		if [ "$TMP" == "#[keyfile]" ]; then	
        	       	sed -i -e '/unmanaged/s/^#//' -e '/\[keyfile\]/s/^#//' ${ETH_CONF}
        	fi
            ;;
    esac
    systemctl restart NetworkManager
}

#Setting ISP and VI clock to maximum and locking it
max_isp_vi_clks() {
	MAX_VI_RATE=$(cat /sys/kernel/debug/bpmp/debug/clk/vi/max_rate)
	MAX_ISP_RATE=$(cat /sys/kernel/debug/bpmp/debug/clk/isp/max_rate)
	MAX_NVCSI_RATE=$(cat /sys/kernel/debug/bpmp/debug/clk/nvcsi/max_rate)
	MAX_VIC_RATE=$(cat /sys/kernel/debug/bpmp/debug/clk/vic/max_rate)
	MAX_EMC_RATE=$(cat /sys/kernel/debug/bpmp/debug/clk/emc/max_rate)

	echo $MAX_VI_RATE > /sys/kernel/debug/bpmp/debug/clk/vi/rate
	echo $MAX_ISP_RATE > /sys/kernel/debug/bpmp/debug/clk/isp/rate
	echo $MAX_NVCSI_RATE > /sys/kernel/debug/bpmp/debug/clk/nvcsi/rate
	echo $MAX_VIC_RATE > /sys/kernel/debug/bpmp/debug/clk/vic/rate
	echo $MAX_EMC_RATE > /sys/kernel/debug/bpmp/debug/clk/emc/rate

	echo 1 > /sys/kernel/debug/bpmp/debug/clk/vi/mrq_rate_locked
	echo 1 > /sys/kernel/debug/bpmp/debug/clk/isp/mrq_rate_locked
	echo 1 > /sys/kernel/debug/bpmp/debug/clk/nvcsi/mrq_rate_locked
	echo 1 > /sys/kernel/debug/bpmp/debug/clk/vic/mrq_rate_locked
	echo 1 > /sys/kernel/debug/bpmp/debug/clk/emc/mrq_rate_locked

}

# fix Jetpack 6 terminal sometime will delay issue.
set_maximize_clock(){
	JP_VER="`cat /etc/nv_tegra_release | grep -oE "R3[0-9]" | sed 's/R//g'`"
	if [ "$JP_VER" == "36" ]; then
		jetson_clocks
	fi
}

case "$1" in
        "boot")
		chkProduct
		osState			
		set_maximize_clock
		disable_eth_eee
		case "$PRODUCT" in
			ATC35*)	# ATC3520 / 3530 / 3540
				BT
				chkGPS
				sleep 5
				modprobe -i ap_m12mo_vbo
				modprobe igb
			;;
				
			"ATC3750")
				USB $ON
				aqr113c_setting $AQR113C_STAT
			;;
				
			"ATC3750-8M")
				if [[ "`nvpmodel -q | grep -oP MAXN`" == "MAXN" ]]; then
					max_isp_vi_clks	
				fi
			;;
		esac          
        ;;
        "resume")
        	if [[ $PRODUCT =~ ^ATC35 ]]; then	# ATC3520 / 3530 / 3540
			osState
		fi
	;;
	"usb-resume")
		chkProduct
		if [[ $PRODUCT =~ ^ATC375 ]]; then
			USB $OFF
			if [[ "$PRODUCT" == "ATC3750-8M" ]]; then
				sleep 1
				USB $ON
			fi
		fi	
	;;	
esac

