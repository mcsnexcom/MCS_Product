/**
 * The program without function menu for accessing MCU.
 *
 * @Team	MR12/MCS
 * @Author 	William Ho
 * @Date	10/07 2020
 */
#include "init.h"
#include "string.h"

struct timeval start1, end1; // test the throughput(received)
long time_use = 0;			 // test the throughput(time used)

bool EXIT_LOOP = false;

/**
 * Handling the signal from key event(ctrl+c).
 *
 * @param sign_no The number of signal
 */
void handle_signal_from_keyevent(int sign_no) {
    printf("The total received data is %d.\n", receiveCANDataCountOnAP);
    printf("\nReceiving signal from key event. The signal no is %d.\n", sign_no);
    EXIT_LOOP = true;
}

/**
 * The callback function which get event or can data from MCU/CAN.
 *
 * @param callback_data the structure of callback data
 */
void callback_gotEventData(CALLBACK_DATA callback_data) {

#if 1
	///*
	receiveCANDataCountOnAP++;
	gettimeofday(&end1, NULL);
	time_use = ((end1.tv_sec - start1.tv_sec) * 1000) + ((end1.tv_usec - start1.tv_usec) / 1000);
	if(time_use == 60000) { // 60 seconds
		printf("The total received data is %d, time used: %d ms.\n", receiveCANDataCountOnAP, time_use);
		EXIT_LOOP = true;
	}
#endif

}

/**
 * Main function.
 */
int main(int argc, char *argv[]) {
	int result = 0, DataInLength = 0, DataOutLength = 0;
	BYTE DataIn[128], DataOut[128];
	char *mcu_port = "";
	char model[20];
	// To register sys log(optional)
	/*
	openlog("MCU AP", LOG_CONS | LOG_PID, 0);
	syslog(LOG_INFO, "MCU AP start ...");
	*/

	// To register the key event
	signal(SIGINT, handle_signal_from_keyevent);

	FILE *file = fopen("/proc/device-tree/product", "rb");
	if(!file){
		perror("fopen");
        	return 1;
	}

	size_t n = fread(model, 1, sizeof(model) - 1, file);
	fclose(file);
	model[n] = '\0';
	char *idx = strstr(model, "ATC3750");
	if(idx){
		mcu_port="/dev/ttyTHS4";
	}
	else{
		mcu_port="/dev/ttyTHS1";
	}
	printf("mcu port : %s\n", mcu_port);
	// ###### To init MCU or CAN {N} and others [START] ######
	// Initiating MCU (the definition of arguments , please see init.h)
	printf("The result of initiating MCU is %d.\n", LAUNCH_INIT_DEV(NULL, 0, mcu_port, 115200, -1));
	// Registerring CallBack function of MCU/CAN Event or data.
	Register_MCU_EventCallBack(1, 1, callback_gotEventData);
	// Initiating the command pool
	INIT_CMD_POOL();
	// ###### To init MCU or CAN {N} and others [END] ######

	// ###### To launch MCU or CAN command [START] ######
	// To retrive the USB 3.0 status from MCU
	///*
	//

//int i=0, count_s=0, count_f=0;
//for (i=0; i<5000; i++)
//{
	int res;
	res = LAUNCH_MCU_COMMAND("ST_SYSTEM_GET_01_01_MCU_VERSION", DataIn, DataInLength, DataOut, &DataOutLength);
	if(res > 0)
	{
		printf("MCU version = %c%02d\n", DataOut[0], DataOut[1]);
//		count_s++;
	}
	else
	{
		printf("Get MCU version failure.\n");
//		count_f++;
	}

	LAUNCH_EXIT("CONFIG_MAIN_EXIT", NULL, 0);

	exit(EXIT_SUCCESS);
}
