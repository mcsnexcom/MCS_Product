/**
 * The program with function menu for accessing MCU.
 *
 * @Team	MR12/MCS
 * @Author 	William Ho
 * @Date	10/07 2020
 */
#include "init.h"
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <time.h>
#include "AP_MENU_LIB.h"

struct timeval start1, end1; // test the throughput(received)
long time_use = 0;			 // test the throughput(time used)
struct timeval tv;

bool EXIT_LOOP = false;

FILE *test_log_fp = NULL;
volatile sig_atomic_t stop = 0;

// 捕捉 Ctrl+C
void handle_sigint(int sig) {
    stop = 1;
}

/**
 * Handling the signal from key event(ctrl+c).
 *
 * @param sign_no The number of signal
 */
void handle_signal_from_keyevent(int sign_no) {
	printf("The total received data is %d.\n", receiveCANDataCountOnAP);
    printf("\nReceiving signal from key event. The signal no is %d.\n", sign_no);
    EXIT_LOOP = true;
}

void log_current_time(FILE *test_log_fp) {
    struct timeval tv;
    struct tm *timeinfo;
    char time_str[64];

    gettimeofday(&tv, NULL);
    timeinfo = localtime(&tv.tv_sec);

    // 格式化日期與時間（到秒）
    strftime(time_str, sizeof(time_str), "[%Y-%m-%d %H:%M:%S", timeinfo);

    // 補上毫秒與右括號，並印出
    fprintf(test_log_fp, "%s.%03ld] ", time_str, tv.tv_usec / 1000);
}
/**
 * The callback function which get event or can data from MCU/CAN.
 *
 * @param callback_data the structure of callback data
 */
void callback_gotEventData(CALLBACK_DATA callback_data) {
#if 1
	int i;
	switch (callback_data.type) {
#if defined(MCU) | defined(ALL)
		case EVENT_TYPE_SYSTEM:
			fprintf(test_log_fp, "================================================================\n");
			log_current_time(test_log_fp);  // 印出時間戳
			fprintf(test_log_fp, "fd(%d) Receive (EVENT_TYPE_SYSTEM) => ", callback_data.fd);
			for (i = 0; i < callback_data.szDataLength; i++)
				fprintf(test_log_fp, "0x%02X ", callback_data.szData[i]);
			fprintf(test_log_fp, "\n");
			break;
		case MCU_TYPE_CUSTOMISE:
			for (i = 0; i < nWheelNumber; i++) {
				if (callback_data.szData[3] == TPMS_Data[i].SensorID[0] &&
					callback_data.szData[4] == TPMS_Data[i].SensorID[1] &&
					callback_data.szData[5] == TPMS_Data[i].SensorID[2] &&
					callback_data.szData[6] == TPMS_Data[i].SensorID[3]) {
					TPMS_Data[i].temp = callback_data.szData[7];
					TPMS_Data[i].psi  = callback_data.szData[8];
					TPMS_Data[i].vol  = callback_data.szData[9];
				}
				float fVol = TPMS_Data[i].vol / 50;
				printf("fd(%d) Wheel %d => T=%d, psi=%d, V=%1.1f\n", callback_data.fd, i, (TPMS_Data[i].temp - 25), TPMS_Data[i].psi, fVol);
			}
			break;
#endif
#if defined(CAN) | defined(ALL)
		case EVENT_TYPE_CAN:
			gettimeofday(&tv, NULL);
			receiveCANDataCountOnAP++;
			printf("(%ld.%ld) [REVEIVE] (LIB)receiveCount: %lu, (LIB)receiveErrorCount: %u, (AP)receiveCount: %u, (LIB)sendCommandSuccessCount: %lu, (LIB)sendCommandErrorCount: %u,(LIB)sendCommandTimeCount: %d\nfd(%d) => ID(0x%x), RTR(%d), IDE(%d), Len(%d), Data1~8(0x%x)(0x%x)(0x%x)(0x%x)(0x%x)(0x%x)(0x%x)(0x%x)\n", tv.tv_sec, tv.tv_usec, callback_data.receiveCANDataCount, callback_data.receiveErrorCount, receiveCANDataCountOnAP, callback_data.sendCommandSuccessCount, callback_data.sendCommandErrorCount, callback_data.sendCommandTimeCount, callback_data.fd, callback_data.canData.id, callback_data.canData.rtr, callback_data.canData.ide, callback_data.canData.dlc, callback_data.canData.data[0], callback_data.canData.data[1], callback_data.canData.data[2], callback_data.canData.data[3], callback_data.canData.data[4], callback_data.canData.data[5], callback_data.canData.data[6], callback_data.canData.data[7]);
			break;
#endif
	}
#endif

}

/**
 * To find the function pointer by the function(key) name
 *
 * @param *keyName the pointer of function(key) name
 *
 * @return the pointer of function
 */


// void log_current_time(FILE *test_log_fp) {
//     time_t rawtime;
//     struct tm *timeinfo;
//     char time_str[64];

//     time(&rawtime);
//     timeinfo = localtime(&rawtime);
//     strftime(time_str, sizeof(time_str), "[%Y-%m-%d %H:%M:%S]", timeinfo);

//     fprintf(test_log_fp, "%s ", time_str);
// }
/**
 * Main function.
 */
int main(int argc, char *argv[]) {
	// To register sys log(optional)
	/*
	openlog("MCU MENU AP", LOG_CONS | LOG_PID, 0);
	syslog(LOG_INFO, "MCU MENU AP start ...");
	*/
	printf("test version: v8\n");
	signal(SIGINT, handle_sigint);
	test_log_fp = fopen("mcu_event_log.txt", "a");
    if (!test_log_fp) {
        perror("Failed to open log file");
        return -1;
    }
	
	fprintf(test_log_fp, "=========mcu_event_log.txt open=========\n");


	// ###### To init MCU or CAN {N} and others [START] ######
	// To include registerring CallBack function of MCU/CAN Event or data.
	//            initiating the command pool
	FILE *fConfig = LAUNCH_INIT_CONFIG(argc, argv);
	if (fConfig == NULL)
		return -1;
	// ###### To init MCU or CAN {N} and others [END] ######

	// ###### To initiate the settings of MENU [START] ######

	int result = 0, DataInLength = 0, DataOutLength = 0;
	BYTE DataIn[128], DataOut[128];
	
    while (!stop) {
        int result;
        int DataInLength = 0;
        unsigned char DataIn[256] = {0};
        unsigned char DataOut[1024] = {0};
        int DataOutLength = 0;

        result = LAUNCH_MCU_COMMAND("ST_SYSTEM_GET_0B_01_SUPPLY_VOLTAGE", DataIn, DataInLength, DataOut, &DataOutLength);
		fprintf(test_log_fp, "================================================================\n");
        log_current_time(test_log_fp);  // 印出時間戳
		
        if (result) {
            fprintf(test_log_fp, "MCU Command Succeeded. DataOutLength = %d\n", DataOutLength);
            for (int i = 0; i < DataOutLength; i++) {
                fprintf(test_log_fp, "%02X ", DataOut[i]);
            }
            fprintf(test_log_fp, "\n");
        } else {
            fprintf(test_log_fp, "MCU Command Failed\n");
        }

        fflush(test_log_fp);
        usleep(500000);
    }

    // 程式結束前關閉檔案
    if (test_log_fp) {
        fclose(test_log_fp);
        printf("Log file closed.\n");
    }
	LAUNCH_EXIT("CONFIG_MAIN_EXIT", fConfig, 1);


	exit(EXIT_SUCCESS);
}
