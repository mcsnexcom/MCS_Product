#ifndef FUNCTION_IP808AR_H
#define FUNCTION_IP808AR_H
/**
 * IP808AR Function Header.
 *
 * Team: MCS,MR12
 * Date: 
 */

/**
 * IP808AR Function
 */

#ifdef __cplusplus
extern "C" {
#endif

int FUNC_IP808AR_FW_VERSION(int cmdIndex, char *pFunctionName);
int FUNC_IP808AR_TEMPERATURE(int cmdIndex, char *pFunctionName);
int FUNC_IP808AR_TOTAL_CONSUMPTION(int cmdIndex, char *pFunctionName);
int FUNC_IP808AR_PORT_STATUS(int cmdIndex, char *pFunctionName);
int FUNC_IP808AR_PORT_POWER_CONSUMPTION(int cmdIndex, char *pFunctionName);
int FUNC_IP808AR_ALL_PORT_LINK_STATUS(int cmdIndex, char *pFunctionName);
int FUNC_IP808AR_PORT_POWER_CONTROL(int cmdIndex, char *pFunctionName);

#endif // FUNCTION_IP808AR_H

#ifdef __cplusplus
}
#endif
