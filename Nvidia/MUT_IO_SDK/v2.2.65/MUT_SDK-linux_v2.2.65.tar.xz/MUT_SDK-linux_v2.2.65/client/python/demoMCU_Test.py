import time, os, sys
from LIB_x86_64 import libPMUT

# Judge the length of arguments
# Set_Server_FIFO(nm)
# Connect to the Service server. Returns 1 for a successful connection; otherwise, it returns 0.
# nm is the service name (in the current version, it must be set to None to successfully connect to the Service).
if len(sys.argv) > 1:
    fifo_path = f"/tmp/{sys.argv[1]}"
    if os.path.exists(fifo_path):
        libPMUT.Set_Server_FIFO(sys.argv[1])
    else:
        print(f"Error: MUT Service FIFO Name incorrect : '{sys.argv[1]}' does not exist in /tmp directory.")
        sys.exit(1)
else:
    libPMUT.Set_Server_FIFO(None)

restList = libPMUT.LAUNCH_MCU_CMD("ST_SYSTEM_GET_01_01_MCU_VERSION", [])

if restList and len(restList) > 0:
    print("[Python] MCU Version: %d." % restList[0])
else:
    print("No MCU version info received.")