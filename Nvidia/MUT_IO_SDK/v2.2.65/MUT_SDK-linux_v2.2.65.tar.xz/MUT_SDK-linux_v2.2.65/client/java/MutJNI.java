import java.util.ArrayList;
import java.util.Scanner;
import java.io.IOException;
import java.lang.InterruptedException;

public class MutJNI {
    static {
        System.loadLibrary("mutjni");
    }
    // Native method: registers the Java callback to native C
    public native void RegEventCF();
    public native int setServerFIFO(String fifoName);
    public native int launchMCUCmd(String cmdName, byte[] dataIn, int dataInLen, byte[] dataOut, int[] dataOutLen);

        // Java method to be called from native code
    public void eventCallback(int type, byte datalen, byte[] data) {
        // System.out.println("eventCallback type: " + type + " data: " + data);
        switch(type) {
            case 3: //nROK7270 event
                if (data != null && data.length > 0) {
                    int d0 = data[0] & 0xFF;  
                    if ((d0 & 0x01) == 1) {
                        System.out.println(" over voltage alarm.");
                    }
                    else if (((d0 >> 1) & 0x01) == 1) {
                        System.out.println(" lower voltage alarm.");
                    }
                    else if (((d0 >> 2) & 0x01) == 1) {
                        System.out.println(" over temperature alarm.");
                    }
                    else if (((d0 >> 3) & 0x01) == 1) {
                        System.out.println(" lower temperature alarm.");
                    }
                }
                break;
            case 4:
                if (data != null && data.length > 0) {
                    int d0 = data[0] & 0xFF;  //

                    if ((d0 & 0x01) == 1)
                        System.out.println(" GPI 1 is high.");
                    else
                        System.out.println(" GPI 1 is low.");

                    if (((d0 >> 1) & 0x01) == 1)
                        System.out.println(" GPI 2 is high.");
                    else
                        System.out.println(" GPI 2 is low.");

                    if (((d0 >> 2) & 0x01) == 1)
                        System.out.println(" GPI 3 is high.");
                    else
                        System.out.println(" GPI 3 is low.");

                    if (((d0 >> 3) & 0x01) == 1)
                        System.out.println(" GPI 4 is high.");
                    else
                        System.out.println(" GPI 4 is low.");
                } else {
                    System.out.println("No data received.");
                }
                break;
            default:
                System.out.println("default.");
                break;
        }
    }
    public static void main(String[] args) {
        MutJNI mut = new MutJNI();        
        Scanner scanner = new Scanner(System.in);
        if (mut.setServerFIFO(null) == 0) {
            System.out.println("Can't find mcu_service !!!");
            return;
        }
        mut.RegEventCF();
        
        byte[] input = new byte[] { 0 };
        int inputLen = 0 ; 
        byte[] output = new byte[1024];
        int[] outLen = new int[] { 0 };

        while (true) {
            System.out.println("===============================================================");
            System.out.println("==          MCU client demo program(Java Version)           ==");
            System.out.println("===============================================================");
            System.out.println(" 1. MCU Version");
            System.out.println(" 2. Other MCU command");
            System.out.println("");
            System.out.println(" Z. >>> Exit Program<<<");
            System.out.println("===============================================================");
            System.out.print("Select which function you want to do: ");
            
            String option = scanner.nextLine();

            if (option.equalsIgnoreCase("Z")) {
                break;
            } else if (option.equals("1")) {
                try {
                    int res2 = mut.launchMCUCmd("ST_SYSTEM_GET_01_01_MCU_VERSION", input, inputLen, output, outLen);
                    for (int i = 0; i < outLen[0]; i++) {
                        System.out.printf("%02X ", output[i]);
                    }
                    System.out.println();                    
                } catch (Exception e) {
                    System.out.println("Error fetching MCU version: " + e.getMessage());
                }
            } else if (option.equals("2")) {

                // 1. Enter tmpCmd
                System.out.print("Enter your command (tmpCmd): ");
                String tmpCmd = scanner.nextLine();

                // 2. Enter input data (hexadecimal string)
                ArrayList<Byte> inputList = new ArrayList<>();
                // System.out.println("inputList:"+ inputList.size());
                // System.exit(1);
                System.out.println("Enter hex values separated by space (e.g., '01 A5 FF'), or press Enter to finish:");
                while (true) {
                    System.out.print(">> ");
                    String line = scanner.nextLine().trim();
                    if (line.isEmpty()) break; 
                    String[] tokens = line.split("\\s+"); //    Split by space
                    for (String token : tokens) {
                        try {
                            int value = Integer.parseInt(token, 16);
                            if (value < 0 || value > 255) {
                                System.out.println("Hex value out of range (00-FF): " + token);
                                continue;
                            }
                            inputList.add((byte) value);
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid hex value: " + token);
                        }
                    }
                }

                // 3. Convert inputList to byte[]
                for (int i = 0; i < inputList.size(); i++) {
                    input[i] = inputList.get(i);
                }
                inputLen = inputList.size();

                System.out.println("\n=============================\n");

                // 5. Call MCU command
                int res = mut.launchMCUCmd(tmpCmd, input, inputLen, output, outLen);
                // System.out.println("Result Code: " + res);
                // System.out.println("Output Length: " + outLen[0]);
                // System.out.print("Output Data (hex): ");
                for (int i = 0; i < outLen[0]; i++) {
                    System.out.printf("0x%02X ", output[i]);
                }
                System.out.println();  
            }

            // Sleep and clear screen
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                // Handle interruption
            }

            try {
                new ProcessBuilder("clear").inheritIO().start().waitFor();
            } catch (IOException | InterruptedException ex) {
                System.out.println("Could not clear screen.");
            }
        }

        System.out.println("End the Java program.");
        scanner.close();
    }
}
