#include <jni.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ClientJavaTest.h"

static JavaVM *g_vm = NULL;
static jobject g_callbackObject = NULL; // Used to store the Java object (GlobalRef)
static jmethodID g_methodID = NULL;
JNIEXPORT jint JNICALL Java_ClientJavaTest_setServerFIFO(JNIEnv *env, jobject obj, jstring fifoPath) {
    const char *nativeStr = NULL;

    if (fifoPath != NULL) {
        nativeStr = (*env)->GetStringUTFChars(env, fifoPath, 0);
    }

    int result = Set_Server_FIFO((char *)nativeStr);

    if (fifoPath != NULL && nativeStr != NULL) {
        (*env)->ReleaseStringUTFChars(env, fifoPath, nativeStr);
    }

    return result;
}
// C callback function: will invoke a Java method
void nativeCallback(int type, unsigned char datalen, unsigned char *data) {
    JNIEnv *env;
    if ((*g_vm)->AttachCurrentThread(g_vm, (void**)&env, NULL) != 0) {
        return;
    }

    // Prepare to convert data to a Java byte[]
    jbyteArray jdata = (*env)->NewByteArray(env, 64); // Assume maximum length is 64
    (*env)->SetByteArrayRegion(env, jdata, 0, 64, (jbyte*)data);

    // Call the Java method
    (*env)->CallVoidMethod(env, g_callbackObject, g_methodID, type, datalen, jdata);

    (*env)->DeleteLocalRef(env, jdata);
}

// JNI_OnLoad: Save the JavaVM pointer
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    g_vm = vm;
    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL Java_ClientJavaTest_RegEventCF(JNIEnv *env, jobject obj) {
    // Create a global reference to retain the Java object
    g_callbackObject = (*env)->NewGlobalRef(env, obj);

    // Find the method ID for the Java callback method
    jclass cls = (*env)->GetObjectClass(env, obj);
    g_methodID = (*env)->GetMethodID(env, cls, "eventCallback", "(IB[B)V");
    if (g_methodID == NULL) {
        printf("Cannot find method eventCallback\n");
        return;
    }

    // Register the native callback to the C function
    Reg_Event_CF(nativeCallback);
}

JNIEXPORT jint JNICALL Java_ClientJavaTest_launchMCUCmd
  (JNIEnv *env, jobject obj, jstring cmdName, jbyteArray dataIn, jint dataInLen, jbyteArray dataOut, jintArray dataOutLen) {
    const char *c_cmd = (*env)->GetStringUTFChars(env, cmdName, 0);
    jbyte *c_dataIn = (*env)->GetByteArrayElements(env, dataIn, NULL);
    unsigned char *c_dataOut = malloc(1024);  // Adjust according to the maximum expected length
    jint *c_dataOutLen = (*env)->GetIntArrayElements(env, dataOutLen, NULL);

    int result = LAUNCH_MCU_CMD((char *)c_cmd,
                                 (unsigned char *)c_dataIn,
                                 dataInLen,
                                 c_dataOut,
                                 (int *)c_dataOutLen);

    // Write the native result back to the Java array
    (*env)->SetByteArrayRegion(env, dataOut, 0, *c_dataOutLen, (jbyte *)c_dataOut);

    // Release resources
    (*env)->ReleaseStringUTFChars(env, cmdName, c_cmd);
    (*env)->ReleaseByteArrayElements(env, dataIn, c_dataIn, JNI_ABORT);
    (*env)->ReleaseIntArrayElements(env, dataOutLen, c_dataOutLen, 0);
    free(c_dataOut);

    return result;
}