public class ClientJavaTest {
    static {
        System.loadLibrary("clientjavatest");
    }

    private final Object lock = new Object();
    private boolean eventReceived = false;

    public native void RegEventCF();
    public native int setServerFIFO(String fifoName);
    public native int launchMCUCmd(String cmdName, byte[] dataIn, int dataInLen, byte[] dataOut, int[] dataOutLen);

    public void eventCallback(int type, byte datalen, byte[] data) {
        System.out.println("[Java] Receive event");    
        eventReceived = true;
    }

    public static void main(String[] args) throws InterruptedException {
        ClientJavaTest mut = new ClientJavaTest();
        if (mut.setServerFIFO(null) == 0) {
            System.out.println("Can't find mcu_service !!!");
            return;
        }
        mut.RegEventCF();

        byte[] input = new byte[] { 0 };
        int inputLen = 0 ; 
        byte[] output = new byte[1024];
        int[] outLen = new int[] { 0 };

        int res2 = mut.launchMCUCmd("ST_SYSTEM_GET_01_01_MCU_VERSION", input, inputLen, output, outLen);
        if (res2 != 0) {
            System.out.println("[Java] MCU Version: ");   
            for (int i = 0; i < outLen[0]; i++) {
                System.out.printf("%02X ", output[i]);
            }
            System.out.println();  
        }

        for (int i = 0; i < 50; i++) {
            if (mut.eventReceived) {
                break;
            }
            try {
                Thread.sleep(100);  // Sleep for 100 milliseconds
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        if (mut.eventReceived) {
            // System.out.println("Event received, stop waiting.");
            System.exit(0);
        } else {
            // System.out.println("Timeout waiting for event.");
        }
    }
}
