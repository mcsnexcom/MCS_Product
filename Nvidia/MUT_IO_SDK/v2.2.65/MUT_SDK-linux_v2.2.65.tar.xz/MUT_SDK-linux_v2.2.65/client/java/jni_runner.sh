#!/bin/bash

read -p "Compile or Run (0: Compile, 1: Run, 2 : Compile Java test program): " WhatToDo

case "$WhatToDo" in
    "0")
        # Find the path to jni.h
        JNI_PATH=$(find /usr/lib -iname jni.h 2>/dev/null)

        # Check if jni.h was found
        if [ -z "$JNI_PATH" ]; then
            echo "Error: jni.h not found"
            exit 1
        fi

        # Change to the directory where this script is located
        SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
        cd "$SCRIPT_DIR" || exit 1
        
        # Extract the path before /include as JAVA_HOME
        JAVA_HOME="${JNI_PATH%%/include*}"
        echo "Detected JAVA_HOME: $JAVA_HOME"

        # Run make with JAVA_HOME as a parameter
        echo "Running make..."
        make -f Makefile JAVA_HOME="$JAVA_HOME"
        ;;

    "1")
        LIB_FOLDER=LIB_x86_64
        # Check if libMUT.so was generated
        if [ ! -f "$LIB_FOLDER/libMUT.so" ]; then
            echo "libMUT.so not found"
            exit 1
        fi
        # Check if libmutjni.so was generated
        if [ ! -f "$LIB_FOLDER/libmutjni.so" ]; then
            echo "libmutjni.so not found"
            exit 1
        fi

        # Run the Java program
        echo "Running Java program..."
        export LD_LIBRARY_PATH=$LIB_FOLDER
        java -Djava.library.path=$LIB_FOLDER MutJNI
        ;;
    "2")
        # Find the path to jni.h
        JNI_PATH=$(find /usr/lib -iname jni.h 2>/dev/null)

        # Check if jni.h was found
        if [ -z "$JNI_PATH" ]; then
            echo "Error: jni.h not found"
            exit 1
        fi

        # Change to the directory where this script is located
        SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
        cd "$SCRIPT_DIR" || exit 1
        
        # Extract the path before /include as JAVA_HOME
        JAVA_HOME="${JNI_PATH%%/include*}"
        echo "Detected JAVA_HOME: $JAVA_HOME"

        # Run make with JAVA_HOME as a parameter
        echo "Running make..."
        make -f Makefile-test JAVA_HOME="$JAVA_HOME"
        ;;
    *)
        echo "Invalid input. Please enter 0 for Compile or 1 for Run."
        exit 1
        ;;
esac
